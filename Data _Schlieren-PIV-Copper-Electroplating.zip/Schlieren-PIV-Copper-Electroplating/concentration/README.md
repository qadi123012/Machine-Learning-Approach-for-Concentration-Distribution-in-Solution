# concentration/

Everything about turning Schlieren frames into Cu2+ concentration fields: the method, the data tables, the simulations and the paper's figures.

```
concentration/
├── data/                  tables from the paper and numbers derived from them
├── simulations/           outputs of codes/02, 03, 06 (and the coupled figure S7)
└── paper_figures/         Figs. 1 to 10 of the manuscript, as published
```

## How the method works

1. **Optics.** Collimated light crosses 10 mm of electrolyte. A refractive-index gradient bends rays by `eps = (L / n0) dn/dx`. After the focusing lens (focal length `f`) the image of the source moves by `a = f * eps` at the knife plane.
2. **Knife edge.** Placed at the 50 % point, the knife converts that shift into a grey value. Moving the knife in ten 0.19 mm steps records, for every pixel, how grey value depends on displacement. That curve is the pixel's own calibration (Fig. 4 and 5 of the paper), so lamp non-uniformity cancels.
3. **Inversion.** A measured grey value is mapped back to `a` through the pixel's monotone calibration curve (spline) or its local slope (linear, Eq. 10). About 91 % of pixels have a monotone curve and an in-range measurement.
4. **Concentration.** With `dn/dC = 1.804e-4 m3/kg`, `dC/dx = (n0 / (f L dn/dC)) a`. Integrating along x from a bulk reference gives `C(x, y)` (Eq. 7), depth-averaged along the 10 mm light path.
5. **Boundary layer.** `delta_c` is where the cathode-side profile reaches 0.99 Cb. `Cs` comes from extrapolating the profile to the wall. `km = D / delta_c`.

## data/

| File | Content |
|---|---|
| `table1_electrode_concentrations.csv` | Cu2+ next to cathode and anode in the three stages (paper Table 1) |
| `table2_mass_transfer_as_published.csv` | delta_c, uncertainty, km,opt, normalised km (paper Table 2) |
| `derived_transport_numbers.csv` | about 20 derived quantities recomputed and compared with the printed values |
| `profile_shape_analysis.csv` | delta99 needed to carry the Faraday flux for linear, erf and exponential profiles |
| `schlieren_optics_parameters.json` | optical numbers from the paper, and separately the assumed simulation values |

## Simulations

All are labelled SIMULATION in the figure titles. Stand-in fields come from Tables 1 and 2; the optics defaults are in `schlierenpiv/constants.py`.

| Figure | What it shows |
|---|---|
| `S1_knife_edge_calibration.png` | calibration curves of three pixels, the valid-pixel map (91.7 %), spline versus linear inversion error |
| `S2_forward_schlieren_stages.png` | true concentration and the simulated 8-bit Schlieren frame for each stage |
| `S3_concentration_reconstruction.png` | reconstructed fields, error maps and mid-height profiles |
| `S4_boundary_layer_profiles.png` | what survives next to the cathode for three profile shapes |
| `S5_dynamic_range_sweep.png` | valid fraction, Cs error and noise versus the largest measurable gradient |
| `S6_preprocessing_effect.png` | reconstruction error for five pre-processing choices |
| `S7_coupled_concentration_velocity.png` | concentration and PIV vectors on one grid |

Numbers are in `reconstruction_metrics.json`, `boundary_layer_recovery.csv`, `dynamic_range_sweep.csv`, `preprocessing_effect.json` and the `log_*.txt` files.

### What the simulations say

**The calibration and inversion work.** Inside the calibrated window the spline recovers ray displacement to about 10 um and concentration to about 0.05 kg/m3 once the bulk reference is removed (S1, S3). The linear slope of Eq. 10 loses accuracy beyond about 0.4 mm of displacement and the spline does not.

**The bulk reference matters more than the noise.** Integration starts from a column assumed to be at Cb. With the assumed stratification and plume amplitudes the real concentration there differs, which shifts whole rows. The error becomes 1.7 kg/m3 in stage 2 and 2.9 kg/m3 in stage 3, and only 40 % of stage 3 pixels land within the quoted +/-2 kg/m3. The stratification amplitudes are assumed; the point is that the reference column needs an independent check.

**The electrode layer saturates the knife-edge window.** A 0.9 mm window at the assumed focal length measures gradients up to 6.7 kg/m3 per mm. The wall layer carries about 110 kg/m3 per mm (82 kg/m3 over 0.75 mm). Those pixels are invalid, forming a band 5.5 to 9.5 pixels wide at each electrode (S4). Integration stops at the band, and Cs must come from outside information.

**Extrapolation cannot recover Cs from the valid pixels.** Linear extrapolation returns 96 to 100 kg/m3 for true values of 22 to 83. An exponential fit works only if the profile really is exponential, and was off by 20 kg/m3 even then, because depth averaging blends several thicknesses (S4, S5). Reaching the wall needs a gradient limit of about 110 kg/m3 per mm, which in this model means a focal length near 6 mm and roughly 20 times more row-to-row noise (S5c: 0.014 to about 0.24 kg/m3).

**delta_c from the data is essentially the edge of the saturated band.** The band edge sits at 0.69 to 1.19 mm (5.5 to 9.5 px) depending on profile shape, close to the reported 0.75 mm, which is itself 6.0 pixels. That makes delta_c a resolution-limited number.

**Flux bound.** If the wall flux equals the Faraday flux, no monotone concave profile can have delta99 below 0.951 mm. The reported 0.75 mm therefore needs a wall flux 1.28 times larger for a linear film, 2.6 times for an erf profile and 5.9 times for an exponential one (`profile_shape_analysis.csv`). The paper discusses the excess; this puts a number on how much has to be explained by something else, such as the diffusion coefficient, current efficiency or optical bias.

**Pre-processing.** Median filtering and a 3 x 3 Gaussian blur leave the error at 0.04 to 0.05 kg/m3. The display enhancement (blur, CLAHE, gamma 0.9) raises it to 5.1 kg/m3 when applied to the measurement only, and still 1.6 kg/m3 when every frame, calibration included, is enhanced independently (S6). CLAHE depends on each image's histogram, so no single point-wise correction exists.

### Caveats

The focal length (0.10 m), source-image width (0.6 mm), noise, stratification and the 30 % side-wall thickening are assumptions, and the saturation findings scale with them. The focal length was chosen so that 91 % of pixels are in range, as reported. If your real window is wider, rerun `codes/03_boundary_layer_and_mass_transfer.py` with your values.

## paper_figures/

Figs. 1 to 10 as extracted from the manuscript: the cell and optics (1, 3), workflow (2, 5), calibration (4), ten Schlieren frames (6), and the baseline, early, intermediate and quasi-steady concentration maps (7 to 10). Check institute policy and copyright before publishing them.
