# PIV/

Everything about the velocity side: parameters, tracer fidelity, the simulations and the paper's figures.

```
PIV/
├── data/                  parameters, tracer and flow numbers, stage summary, Fig. 15 values
├── simulations/           outputs of codes/04 and 05
└── paper_figures/         Figs. 1 and 11 to 15 of the manuscript, as published
```

## How the method works

Hollow glass spheres (10 um, 1050 kg/m3) are lit by a pulsed 532 nm sheet. Two frames four steps apart (dt = 0.1 s) are processed in PIVlab with FFT multi-pass correlation: 64 then 32 px windows, 50 % overlap, Gaussian three-point sub-pixel peak, normalised median validation. With 0.125 mm per pixel the vector spacing is 2.0 mm, so roughly ten vectors span the 20 mm gap (nine interior columns in the simulation, centred 2 to 18 mm). Velocity is `u = C * dx_px / dt`.

## data/

| File | Content |
|---|---|
| `piv_parameters.json` | tracers, optics, correlation settings, quoted uncertainty, stage velocity ranges |
| `tracer_and_flow_numbers.csv` | Re, Pe, response time, Stokes number, settling velocity and pixel displacements, recomputed and compared with the paper |
| `velocity_stage_summary.csv` | the three stages: time, velocity range, Re, description |
| `transport_mechanism_fractions_fig15.csv` | the values printed on Fig. 15, transcribed. The paper does not describe how they were derived |

Tracer fidelity checks out: tau_p = 5.3 us, St = 7.8e-7, and the tracers **rise** at 1.24 um/s (they are lighter than the electrolyte, so the terminal velocity is negative), which is 0.155 % of 0.8 mm/s and 0.025 % of 5 mm/s.

## Simulations

The stand-in fields are divergence-free counter-clockwise rolls (down at the anode, up at the cathode) scaled to the quoted peaks of 4.1, 6.6 and 8.0 mm/s, with a nascent plume in stage 1 and two meandering plumes in stage 3. They are not CFD and not measurements.

| Figure | What it shows |
|---|---|
| `P1_particle_image_pair.png` | synthetic frame n and n+4 and their overlay |
| `P2_stage_velocity_fields.png` | stand-in truth and PIV result for the three stages |
| `P3_gap_velocity_profiles.png` | speed across the gap at mid-height, mean and spread over 20 seedings (compare Fig. 14) |
| `P4_displacement_accuracy.png` | RMS error versus true displacement from 0.2 to 8 px |
| `P5_coupled_concentration_velocity.png` | concentration with vectors, and the same grid with concentration contours |

Numbers: `piv_metrics.json`, `displacement_accuracy.csv`, `coupled_registration_metrics.json`.

### What the simulations say

| Result | Value |
|---|---|
| Sub-pixel RMS error | 0.04 to 0.06 px, almost independent of displacement |
| Error relative to displacement at 0.64 px / 1.0 px / 2.5 px / 5.28 px | 9.2 % / 4.0 % / 2.1 % / 0.8 % |
| RMS velocity error, stage 1 / 2 / 3 | 0.07 / 0.10 / 0.14 mm/s, which is 6.1 / 2.9 / 4.1 % of the RMS speed |
| Outlier fraction after validation | 0 % (stages 1, 2), 0.4 % (stage 3) |
| Peak speed recovered (mean of 20 seedings) | 3.71 vs 4.1, 6.24 vs 6.6, 7.48 vs 8.0 mm/s |

* **Stage 1 is sub-pixel limited.** At 0.64 px the fixed 0.05 px error is about 9 % of the displacement, or about 0.07 mm/s on a 0.8 mm/s flow. This supports the manuscript's caution about stage 1.
* **Stages 2 and 3 land near, not under, the quoted 2.1 %.** Here the RMS error is 2.9 % and 4.1 %. The difference depends on the particle density, noise and the sharpness of the plumes in the stand-in field, so treat it as an order-of-magnitude check, not a contradiction.
* **Narrow structures are averaged.** A 32 px window is 4 mm wide; plumes 2 to 4 mm wide lose 5 to 9 % of their peak. The "localized 8.0 mm/s peak" in the real data may be low for the same reason.
* **No vector sits inside the concentration boundary layer.** The nearest vector to an electrode is 2.0 mm away, outside the 0.75 to 1 mm layer. Consequently the 0.12 mm registration residual changes the concentration sampled at the vector nodes by less than 0.5 kg/m3 (`coupled_registration_metrics.json`). The 16 % residual-to-delta ratio in the paper matters for profiles, not for the vector grid.
* **Ray bending is not simulated.** The manuscript says it is not corrected in strongly stratified regions; that effect is outside these simulations.

## paper_figures/

Fig. 1 (cell and optics), Figs. 11 to 13 (velocity fields for the three stages, two instants each), Fig. 14 (speed profiles across the gap) and Fig. 15 (transport-mechanism split). Check institute policy and copyright before publishing them.
