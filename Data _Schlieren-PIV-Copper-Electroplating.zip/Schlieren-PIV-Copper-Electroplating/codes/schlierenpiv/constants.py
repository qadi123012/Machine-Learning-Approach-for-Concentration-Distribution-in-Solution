"""Every number used by the code, in SI units unless the name says otherwise.

[paper]   = stated in the manuscript
[derived] = computed from [paper] values
[assumed] = NOT stated in the manuscript; chosen for the simulations. Change these
            to match your instrument, and expect simulation results to depend on them.
"""
import numpy as np

# ---- Electrochemistry [paper, Sections 2.1, 5] -------------------------------
CB = 100.0                 # kg Cu2+ / m3, bulk concentration (0.100 g/mL)
I_DENSITY = 185.0          # A / m2
N_ELECTRONS = 2
FARADAY = 96485.0          # C / mol
M_CU = 63.55e-3            # kg / mol
D_CU = 7.14e-10            # m2 / s, Cu2+ diffusion coefficient
GAP = 20e-3                # m, anode (x = 0) to cathode (x = 20 mm)
H_ELECTRODE = 0.045        # m, characteristic height L
DEPTH = 10e-3              # m, optical path through the electrolyte
TEMPERATURE_C = 25.0

# ---- Table 1: electrode-adjacent concentration (kg/m3) [paper] ---------------
STAGES = ("early", "developed", "late")
STAGE_LABELS = {"early": "Stage 1 (0-5 min)", "developed": "Stage 2 (5-10 min)",
                "late": "Stage 3 (10-15 min)"}
C_ANODE = {"early": 135.0, "developed": 150.0, "late": 160.0}
C_CATHODE = {"early": 80.0, "developed": 45.0, "late": 18.0}

# ---- Table 2: boundary layer thickness (m) [paper] ---------------------------
DELTA_C = {"early": 0.96e-3, "developed": 0.85e-3, "late": 0.75e-3}
DELTA_C_UNC = {"early": 0.05e-3, "developed": 0.07e-3, "late": 0.08e-3}
KM_OPT_QUOTED = {"early": 7.44e-7, "developed": 8.40e-7, "late": 9.52e-7}
KM_NORM_QUOTED = {"early": 0.78, "developed": 0.88, "late": 1.00}

# ---- Flow [paper, Sections 4.5 and 5] ----------------------------------------
V_STAGE_MIN = 0.8e-3       # m/s
V_STAGE_MAX = {"early": 2.5e-3, "developed": 6.6e-3, "late": 6.6e-3}
V_PLUME_STAGE1 = 4.1e-3    # nascent anodic plume at end of stage 1
V_LOCAL_PEAK = 8.0e-3      # localized peak in stage 3
NU = 1.0e-6                # m2 / s (= D * Sc)
SC = 1401.0
RHO_F = 1075.0             # kg / m3
MU = 1.1e-3                # Pa s
GR_QUOTED = 7.33e6
SH_QUOTED = 187.8

# ---- Tracers [paper, Section 4.5] --------------------------------------------
DP = 10e-6                 # m, hollow glass spheres
RHO_P = 1050.0             # kg / m3
G = 9.81

# ---- Optics and imaging [paper, Sections 2.3, 3.1, 3.2] ----------------------
N0 = 1.3414                # refractive index of bulk electrolyte, 475 nm band
DNDC = 1.804e-4            # m3 / kg  (= 1.804e-4 L/g)
CONC_PRECISION_2SIGMA = 2.0
PIXEL = 1.25e-4            # m / pixel (0.125 mm)
DT_PIV = 0.100             # s, correlation interval (frame n and n+4)
T_EXPOSURE = 0.025         # s
WINDOW_FINAL = 32          # px
WINDOW_FIRST = 64          # px
OVERLAP = 0.5
VECTOR_SPACING = 2.0e-3    # m
REGISTRATION_RESIDUAL = 0.12e-3   # m
KNIFE_STEP = 0.19e-3       # m
KNIFE_POSITIONS = 10
MONOTONIC_FRACTION = 0.91
SPLINE_RESIDUAL_COUNTS = 2.0
PIV_UNCERTAINTY_PCT = 2.1  # stage 2-3

# ---- [assumed] simulation parameters (not given in the manuscript) -----------
FOCAL_LENGTH = 0.10        # m, focusing lens. Chosen so that ~91 % of pixels stay monotonic
SOURCE_SIGMA = 0.6e-3      # m, half-width of the source image at the knife plane
I_MAX = 230.0              # counts, full transmission
GAIN_RANGE = (0.85, 1.00)  # pixel-to-pixel illumination non-uniformity
READ_NOISE = 1.5           # counts, per image
CAL_FRAMES_AVERAGED = 10
SIDEWALL_KAPPA = 0.30      # boundary layer thickens by 30 % at the side walls (3-D effect)
STRATIFICATION = {"early": 0.0, "developed": 3.0, "late": 5.0}   # kg/m3, bottom minus top / 2
PLUME_AMPLITUDE = {"early": 4.0, "developed": 8.0, "late": 10.0}  # kg/m3
PARTICLES_PER_PIXEL = 0.04
PARTICLE_SIGMA_PX = 1.0

# ---- Derived ------------------------------------------------------------------
J_FARADAY = I_DENSITY / (N_ELECTRONS * FARADAY) * M_CU       # kg / (m2 s)
