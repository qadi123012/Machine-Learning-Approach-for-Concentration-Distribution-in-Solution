"""Synthetic concentration and velocity fields used to test the measurement chain.

These are STAND-IN fields, built from the stage values in Tables 1 and 2 of the
manuscript (electrode concentrations, boundary-layer thickness, peak velocities).
They are not measurements and not CFD results. Geometry follows the manuscript:
anode at x = 0, cathode at x = 20 mm, y vertical (0 = bottom, 45 mm = top).
"""
import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.special import erf
from . import constants as K

ERF_KAPPA = 1.8213            # erf(kappa) = 0.99


def shape_function(name, eta):
    """Dimensionless wall-normal profile s(eta): s(0) = 0, s(1) = 0.99 (film: 1.0)."""
    eta = np.maximum(np.asarray(eta, float), 0.0)
    if name == "film":
        return np.clip(eta, 0.0, 1.0)
    if name == "erf":
        return erf(ERF_KAPPA * eta)
    if name == "exp":
        return 1.0 - np.exp(-np.log(100.0) * eta)
    raise ValueError(name)


def wall_slope(name):
    """ds/d(eta) at the wall."""
    return {"film": 1.0, "erf": 2.0 * ERF_KAPPA / np.sqrt(np.pi), "exp": np.log(100.0)}[name]


def grid(ny=360, nx_fine=800):
    dxf = K.GAP / nx_fine
    x = (np.arange(nx_fine) + 0.5) * dxf
    y = (np.arange(ny) + 0.5) * K.PIXEL
    return x, y, dxf


def make_concentration(stage, shape="film", ny=360, nx_fine=800, nz=9,
                       kappa=K.SIDEWALL_KAPPA, delta=None, with_bulk_structure=True):
    """Depth-averaged ('projected') Cu2+ field and its x-gradient.

    Returns a dict with arrays on (y rows, fine x columns) and on the camera pixel grid
    (x binned by factor nx_fine / 160). The depth variation (boundary layer thicker near the
    side walls by `kappa`) makes the line-of-sight average differ from the mid-plane field.
    """
    x, y, dxf = grid(ny, nx_fine)
    X, Y = np.meshgrid(x, y)
    H = ny * K.PIXEL
    d0 = K.DELTA_C[stage] if delta is None else delta
    Cs, Ca = K.C_CATHODE[stage], K.C_ANODE[stage]
    if with_bulk_structure:
        strat = K.STRATIFICATION[stage] * (1.0 - 2.0 * Y / H)            # denser at the bottom
        xp = 2.5e-3 + 0.6e-3 * np.sin(2 * np.pi * Y / 0.020)             # meandering plume
        plume = K.PLUME_AMPLITUDE[stage] * np.exp(-((X - xp) / 2.0e-3) ** 2) * (1.0 - Y / H)
        Cb_loc = K.CB + strat + plume
    else:
        Cb_loc = np.full_like(X, K.CB)
    C_acc = np.zeros_like(X)
    G_acc = np.zeros_like(X)
    C_mid = None
    for k in range(nz):
        zeta = 2.0 * (k + 0.5) / nz - 1.0                                  # -1 ... 1 across the depth
        dz = d0 * (1.0 + kappa * zeta ** 2)
        Ccath = Cs + (Cb_loc - Cs) * shape_function(shape, (K.GAP - X) / dz)
        Can = Ca - (Ca - Cb_loc) * shape_function(shape, X / dz)
        Cz = Ccath + Can - Cb_loc
        Cz = gaussian_filter1d(Cz, sigma=max(1.0, 0.08 * dz / dxf), axis=1, mode="nearest")
        C_acc += Cz / nz
        G_acc += np.gradient(Cz, dxf, axis=1) / nz
        if k == nz // 2:
            C_mid = Cz
    f = nx_fine // 160
    binx = lambda A: A.reshape(A.shape[0], 160, f).mean(axis=2)
    return dict(x=x, y=y, dxf=dxf, C_proj=C_acc, G_proj=G_acc, C_mid=C_mid,
                C_proj_px=binx(C_acc), G_proj_px=binx(G_acc), C_mid_px=binx(C_mid),
                x_px=(np.arange(160) + 0.5) * K.PIXEL, shape=shape, stage=stage, delta=d0)


# ----------------------------------------------------------------------------- velocity
def stream_function(x_mm, y_mm, stage, t=0.0, Lx=20.0, H=45.0):
    """Stream function psi (mm2/s). Counter-clockwise roll: down at the anode (x = 0), up at the
    cathode (x = 20 mm). Stage 1 adds a nascent anodic plume, stage 3 two meandering plumes."""
    A = {"early": 1.2, "developed": 6.6, "late": 5.5}[stage] * Lx / np.pi
    psi = A * np.sin(np.pi * x_mm / Lx) * np.sin(np.pi * y_mm / H)
    g = np.sin(np.pi * y_mm / H) ** 2
    if stage == "early":
        s = 2.0
        psi = psi + 2.9 * s * np.sqrt(np.pi) / 2 * erf((x_mm - 1.5) / s) * g
    if stage == "late":
        s = 1.6
        for amp, x0, ph in ((2.5, 2.5, 0.0), (2.0, 17.0, 1.7)):
            xc = x0 + 0.9 * np.sin(2 * np.pi * (y_mm / 18.0 - t / 4.0) + ph)
            psi = psi + amp * s * np.sqrt(np.pi) / 2 * erf((x_mm - xc) / s) * g
    return psi


def velocity_mm_s(x_mm, y_mm, stage, t=0.0, h=0.01):
    """(u, v) in mm/s from the stream function, so div(u) = 0 by construction."""
    u = (stream_function(x_mm, y_mm + h, stage, t) - stream_function(x_mm, y_mm - h, stage, t)) / (2 * h)
    v = -(stream_function(x_mm + h, y_mm, stage, t) - stream_function(x_mm - h, y_mm, stage, t)) / (2 * h)
    return u, v


PEAK_TARGET_MM_S = {"early": K.V_PLUME_STAGE1 * 1e3, "developed": K.V_STAGE_MAX["developed"] * 1e3,
                    "late": K.V_LOCAL_PEAK * 1e3}


def peak_scale(stage, t=0.0):
    """Factor that makes the peak speed equal the value quoted in the manuscript."""
    xx, yy = np.meshgrid(np.linspace(0, 20, 161), np.linspace(0, 45, 361))
    u, v = velocity_mm_s(xx, yy, stage, t)
    return PEAK_TARGET_MM_S[stage] / np.hypot(u, v).max()


def velocity_field(stage, t=0.0):
    """Callable returning (u, v) in m/s for positions in mm, scaled to the quoted peak."""
    s = peak_scale(stage, t)
    def f(x_mm, y_mm):
        u, v = velocity_mm_s(x_mm, y_mm, stage, t)
        return s * u * 1e-3, s * v * 1e-3
    return f
