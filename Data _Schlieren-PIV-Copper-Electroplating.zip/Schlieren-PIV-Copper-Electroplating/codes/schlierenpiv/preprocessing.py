"""Pre-processing for the QUANTITATIVE path and a single-channel copy of the display enhancement."""
import cv2
import numpy as np


def quantitative_preprocess(img, background=None, median_ksize=3):
    """Background subtraction (optional) and median filtering only. Both are (nearly) linear in the
    grey value, so the pixel-wise knife-edge calibration remains valid if the same operations are applied
    to the calibration images."""
    f = img.astype(np.float32)
    if background is not None:
        f = f - background
    k = median_ksize
    # cv2.medianBlur needs 8-bit for k > 5; scipy handles float for any k
    from scipy.ndimage import median_filter
    return median_filter(f, size=k, mode="nearest")


def display_enhance_gray(img, blur=3, clip=2.0, tile=8, gamma=0.9):
    """Gaussian blur -> CLAHE -> gamma on a single 8-bit-range channel (same as image_enhancement.py,
    without the up-scaling). Returns float counts in 0..255."""
    f = np.clip(img, 0, 255).astype(np.float32) / 255.0
    f = cv2.GaussianBlur(f, (blur, blur), 0)
    u8 = (f * 255).astype(np.uint8)
    u8 = cv2.createCLAHE(clipLimit=clip, tileGridSize=(tile, tile)).apply(u8)
    return (np.power(u8 / 255.0, gamma) * 255).astype(np.uint8).astype(np.float64)
