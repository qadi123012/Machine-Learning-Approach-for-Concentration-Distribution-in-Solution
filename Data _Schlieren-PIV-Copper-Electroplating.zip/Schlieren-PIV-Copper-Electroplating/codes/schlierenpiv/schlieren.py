"""Knife-edge Schlieren: forward model, pixel-wise calibration and inversion to concentration.

Chain (manuscript Eqs. 2-10):
    dC/dx --(dn/dC)--> dn/dx --(L/n0)--> eps --(f)--> a (ray displacement at the knife plane)
    knife-edge transmission I = g * Imax * Phi((a - dx) / sigma_s)   (monotone sigmoid, 50 % at a = dx)
Calibration: I_ij is recorded for K knife positions dx_k; a measurement I' is converted back to a
by inverting the pixel's own monotone curve (spline) or with the local slope S_ij (linear, Eq. 10).
Then n(x) follows by integrating the gradient along x from a bulk reference (Eq. 7) and
C = C0 + (n - n0) / (dn/dC).
"""
from dataclasses import dataclass
import numpy as np
from scipy.special import erf
from . import constants as K


@dataclass
class Optics:
    f: float = K.FOCAL_LENGTH
    L: float = K.DEPTH
    n0: float = K.N0
    dndC: float = K.DNDC
    sigma_s: float = K.SOURCE_SIGMA
    imax: float = K.I_MAX
    read_noise: float = K.READ_NOISE
    cal_frames: int = K.CAL_FRAMES_AVERAGED

    @property
    def a_per_gradient(self):
        """Ray displacement (m) per unit concentration gradient (kg m-4)."""
        return self.f * self.L / self.n0 * self.dndC

    def gradient_limit(self, a_max):
        """Largest |dC/dx| (kg m-4) that keeps |a| <= a_max."""
        return a_max / self.a_per_gradient


def phi(z):
    return 0.5 * (1.0 + erf(z / np.sqrt(2.0)))


def knife_positions(n=K.KNIFE_POSITIONS, step=K.KNIFE_STEP):
    return (np.arange(n) - (n - 1) / 2.0) * step


def make_gain_map(shape, rng, gain_range=K.GAIN_RANGE):
    yy, xx = np.mgrid[0:shape[0], 0:shape[1]]
    base = 0.5 * (1 + np.cos(np.pi * (xx / shape[1] - 0.5))) * 0.5 + 0.5       # smooth vignetting 0.5..1
    g = gain_range[0] + (gain_range[1] - gain_range[0]) * (0.7 * base + 0.3 * rng.random(shape))
    return g.astype(np.float64)


def _quantise(img):
    return np.clip(np.round(img), 0, 255)


def transmission(a, dx, gain, opt):
    return gain * opt.imax * phi((a - dx) / opt.sigma_s)


def simulate_calibration(gain, opt, rng, positions=None):
    """Mean of `cal_frames` noisy images per knife position, returned as float counts."""
    positions = knife_positions() if positions is None else positions
    stack = []
    for dx in positions:
        clean = transmission(0.0, dx, gain, opt)
        noise = rng.normal(0, opt.read_noise, (opt.cal_frames,) + gain.shape).mean(axis=0)
        stack.append(clean + noise)
    return positions, np.stack(stack)                   # (K,), (K, ny, nx)


def simulate_measurement(G, gain, opt, rng):
    """One 8-bit Schlieren frame for a gradient field G (kg m-4); also returns the true a."""
    a = G * opt.a_per_gradient
    I = transmission(a, 0.0, gain, opt) + rng.normal(0, opt.read_noise, G.shape)
    return _quantise(I), a


# ------------------------------------------------------------------------------ inversion
def _pchip_slopes(x, y):
    """Fritsch-Carlson monotone slopes, vectorised over trailing pixel axes. x: (K, ...), y: (K, ...)."""
    h = np.diff(x, axis=0)
    d = np.diff(y, axis=0) / h
    m = np.zeros_like(y)
    same = d[:-1] * d[1:] > 0
    w1 = 2 * h[1:] + h[:-1]
    w2 = h[1:] + 2 * h[:-1]
    with np.errstate(divide="ignore", invalid="ignore"):
        hm = (w1 + w2) / (w1 / d[:-1] + w2 / d[1:])
    m[1:-1] = np.where(same, hm, 0.0)
    m[0] = d[0]
    m[-1] = d[-1]
    return m


def invert_spline(I_meas, positions, I_cal, margin=2.0):
    """a (m) for every pixel by inverting its monotone calibration curve with a monotone cubic.

    Returns (a, valid). valid is False where the calibration curve is not monotone or where the
    measurement lies outside the calibrated intensity range (saturation of the knife-edge response)."""
    Kn = len(positions)
    # I decreases with dx: reverse so the abscissa (intensity) is increasing
    I = I_cal[::-1]
    dx = np.broadcast_to(positions[::-1, None, None], I.shape).astype(float)
    mono = np.all(np.diff(I, axis=0) > 0, axis=0)
    lo, hi = I[0], I[-1]
    inside = (I_meas > lo + margin) & (I_meas < hi - margin)
    m = _pchip_slopes(I, dx)
    # segment index for each pixel
    idx = np.zeros(I_meas.shape, dtype=int)
    for k in range(1, Kn - 1):
        idx += (I_meas >= I[k]).astype(int)
    idx = np.clip(idx, 0, Kn - 2)
    take = lambda A, i: np.take_along_axis(A, i[None], axis=0)[0]
    x0, x1 = take(I, idx), take(I, idx + 1)
    y0, y1 = take(dx, idx), take(dx, idx + 1)
    m0, m1 = take(m, idx), take(m, idx + 1)
    h = np.where(x1 - x0 == 0, 1.0, x1 - x0)
    t = np.clip((I_meas - x0) / h, 0, 1)
    h00 = 2 * t ** 3 - 3 * t ** 2 + 1
    h10 = t ** 3 - 2 * t ** 2 + t
    h01 = -2 * t ** 3 + 3 * t ** 2
    h11 = t ** 3 - t ** 2
    dx_star = h00 * y0 + h10 * h * m0 + h01 * y1 + h11 * h * m1
    return -dx_star, (mono & inside)             # a = -dx*


def invert_linear(I_meas, positions, I_cal):
    """Eq. (10): a = dI' / S_ij with S_ij the slope at the reference (central two positions)."""
    c = len(positions) // 2
    S = -(I_cal[c] - I_cal[c - 1]) / (positions[c] - positions[c - 1])          # dI/da > 0
    I_ref = 0.5 * (I_cal[c] + I_cal[c - 1])
    return (I_meas - I_ref) / S, np.ones(I_meas.shape, bool)


def displacement_to_gradient(a, opt):
    """dC/dx (kg m-4) from ray displacement a (Eq. 6 rearranged, then dn/dC)."""
    return a / opt.a_per_gradient


def integrate_rows(G, valid, dx, ref_col, C_ref):
    """Integrate dC/dx along x from a bulk reference column (Eq. 7), row by row.

    Integration stops at the first invalid pixel on each side, so the saturated wall layers are
    left as NaN (they are handled by extrapolation in `boundary_layer`)."""
    ny, nx = G.shape
    C = np.full((ny, nx), np.nan)
    C[:, ref_col] = C_ref
    alive = np.ones(ny, bool)
    for j in range(ref_col + 1, nx):                                   # towards the cathode
        alive &= valid[:, j] & valid[:, j - 1]
        C[alive, j] = C[alive, j - 1] + 0.5 * (G[alive, j] + G[alive, j - 1]) * dx
    alive = np.ones(ny, bool)
    for j in range(ref_col - 1, -1, -1):                               # towards the anode
        alive &= valid[:, j] & valid[:, j + 1]
        C[alive, j] = C[alive, j + 1] - 0.5 * (G[alive, j] + G[alive, j + 1]) * dx
    return C


def run_chain(field, opt, rng, method="spline", preprocess=None, cal_preprocess=None):
    """Forward + calibration + inversion + integration for one stage field. Returns a dict."""
    G_true = field["G_proj_px"]
    gain = make_gain_map(G_true.shape, rng)
    positions, I_cal = simulate_calibration(gain, opt, rng)
    I_meas, a_true = simulate_measurement(G_true, gain, opt, rng)
    if cal_preprocess is not None:
        I_cal = np.stack([cal_preprocess(im) for im in I_cal])
    if preprocess is not None:
        I_meas = preprocess(I_meas)
    if method == "spline":
        a_hat, valid = invert_spline(I_meas, positions, I_cal)
    else:
        a_hat, valid = invert_linear(I_meas, positions, I_cal)
        a_lim = 0.5 * np.abs(positions).max()
        valid = np.abs(a_hat) < a_lim
    G_hat = displacement_to_gradient(a_hat, opt)
    nx = G_hat.shape[1]
    C_hat = integrate_rows(G_hat, valid, K.PIXEL, nx // 2, K.CB)
    return dict(G_true=G_true, G_hat=G_hat, a_true=a_true, a_hat=a_hat, valid=valid,
                C_hat=C_hat, I_meas=I_meas, I_cal=I_cal, positions=positions, gain=gain)
