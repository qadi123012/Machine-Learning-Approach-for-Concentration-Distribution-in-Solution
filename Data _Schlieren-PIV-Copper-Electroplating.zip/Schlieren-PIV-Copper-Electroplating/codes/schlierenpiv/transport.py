"""Closed-form transport quantities of the manuscript (Sections 4.5 and 5)."""
import numpy as np
from . import constants as K


def j_faraday(i=K.I_DENSITY, n=K.N_ELECTRONS, M=K.M_CU, F=K.FARADAY):
    """Eq. (16): J = i M / (n F)  [kg m-2 s-1]."""
    return i / (n * F) * M


def km_required(delta_c_conc, J=None):
    """Eq. (17): km,req = J_Faraday / (Cb - Cs)  [m/s]."""
    J = j_faraday() if J is None else J
    return J / delta_c_conc


def km_film(delta, D=K.D_CU):
    """Film model: km = D / delta_c  [m/s]."""
    return D / delta


def j_diffusive(dC, delta, D=K.D_CU):
    """Eq. (14): J_diff = D (Cb - Cs) / delta."""
    return D * dC / delta


def reynolds(v, L=K.H_ELECTRODE, nu=K.NU):
    return v * L / nu


def peclet(v, L=K.H_ELECTRODE, D=K.D_CU):
    return v * L / D


def grashof(beta_s, dC, L=K.H_ELECTRODE, nu=K.NU, g=K.G):
    return g * beta_s * dC * L ** 3 / nu ** 2


def implied_beta_s(Gr, dC, L=K.H_ELECTRODE, nu=K.NU, g=K.G):
    """Solutal expansion coefficient that would give a quoted Grashof number."""
    return Gr * nu ** 2 / (g * dC * L ** 3)


def sherwood_vertical_plate(Gr, Sc):
    """Eq. (18): Sh = 0.59 (Gr Sc)^(1/4)."""
    return 0.59 * (Gr * Sc) ** 0.25


def km_convective(Sh, L=K.H_ELECTRODE, D=K.D_CU):
    """Eq. (19)."""
    return Sh * D / L


def stokes_response_time(dp=K.DP, rho_p=K.RHO_P, mu=K.MU):
    return rho_p * dp ** 2 / (18.0 * mu)


def stokes_number(v, L=K.H_ELECTRODE):
    return stokes_response_time() / (L / v)


def terminal_velocity(dp=K.DP, rho_p=K.RHO_P, rho_f=K.RHO_F, mu=K.MU, g=K.G):
    """Settling velocity; NEGATIVE means the particle rises (rho_p < rho_f)."""
    return (rho_p - rho_f) * g * dp ** 2 / (18.0 * mu)


def displacement_px(v, dt=K.DT_PIV, C=K.PIXEL):
    """PIV displacement in pixels for a velocity v (inverse of Eq. 11)."""
    return v * dt / C
