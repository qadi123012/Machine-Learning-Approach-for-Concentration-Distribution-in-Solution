"""Boundary-layer thickness, wall concentration and mass-transfer coefficient from profiles.

Definitions follow Section 5.2 of the manuscript: delta_c is the distance from the electrode
where the concentration reaches 0.99 Cb (cathode side) and Cs is obtained by extrapolating the
measured profile to the wall. km = D / delta_c (film model).
"""
import numpy as np
from scipy.optimize import curve_fit
from . import constants as K
from . import transport as T


def wall_distance(x_px, side):
    """Distance from the electrode for pixel-centre positions x_px (m)."""
    return (K.GAP - x_px) if side == "cathode" else x_px


def delta99(dist, C, side, Cb=K.CB, frac=0.01):
    """First distance from the wall at which |C - Cb| <= frac * Cb (profile ordered from the wall)."""
    order = np.argsort(dist)
    d, c = dist[order], C[order]
    ok = ~np.isnan(c)
    d, c = d[ok], c[ok]
    hit = np.where(np.abs(c - Cb) <= frac * Cb)[0]
    if hit.size == 0:
        return np.nan
    i = hit[0]
    if i == 0:
        return d[0]
    # linear interpolation between the last point outside and the first inside the band
    target = Cb - frac * Cb if side == "cathode" else Cb + frac * Cb
    c0, c1, d0, d1 = c[i - 1], c[i], d[i - 1], d[i]
    return d0 + (target - c0) / (c1 - c0) * (d1 - d0) if c1 != c0 else d1


def saturation_edge(dist, valid_row):
    """Distance from the wall of the first valid pixel, i.e. the outer edge of the saturated band."""
    order = np.argsort(dist)
    d, v = dist[order], valid_row[order]
    if not v.any():
        return np.nan
    return d[np.argmax(v)]


def extrapolate_linear(dist, C, n=3):
    """Cs from a straight-line fit to the n valid points closest to the wall."""
    ok = ~np.isnan(C)
    d, c = dist[ok], C[ok]
    if d.size < n:
        return np.nan
    o = np.argsort(d)[:n]
    p = np.polyfit(d[o], c[o], 1)
    return float(np.polyval(p, 0.0))


def extrapolate_exponential(dist, C, side, Cb=K.CB, n=8):
    """Cs from fitting |C - Cb| = A exp(-d / lambda) to the n valid points closest to the wall.

    Returns (Cs, lambda) or (nan, nan) when the tail carries no usable signal."""
    ok = ~np.isnan(C)
    d, c = dist[ok], C[ok]
    o = np.argsort(d)[:n]
    d, c = d[o], c[o]
    y = np.abs(c - Cb)
    if y.max() < 1.0 or d.size < 4:
        return np.nan, np.nan
    try:
        p, _ = curve_fit(lambda s, A, lam: A * np.exp(-s / lam), d, y, p0=(y.max() * 2, 1e-3),
                         bounds=([0, 1e-5], [1000, 1e-1]), maxfev=2000)
    except Exception:
        return np.nan, np.nan
    sign = -1.0 if side == "cathode" else 1.0
    return Cb + sign * p[0], p[1]


def mass_transfer_summary(delta_c, Cs):
    """km,opt = D / delta_c; the Faraday-law requirement uses Cb - Cs. Returns a dict."""
    dC = K.CB - Cs
    return dict(delta_c_mm=delta_c * 1e3, Cs=Cs, dC=dC,
                km_opt=T.km_film(delta_c), km_req=T.km_required(dC),
                J_diff=T.j_diffusive(dC, delta_c), J_faraday=T.j_faraday(),
                ratio_opt_over_req=T.km_film(delta_c) / T.km_required(dC))


def minimum_delta99_for_flux(J=None, dC=None, frac=0.01):
    """Smallest delta99 compatible with a wall flux J for ANY monotone concave profile.

    A concave profile lies below its wall tangent, so reaching (1 - frac) of the driving
    difference needs at least (1 - frac) * dC / (J / D) of distance. Equality holds for the
    linear film profile."""
    J = T.j_faraday() if J is None else J
    dC = (K.CB - K.C_CATHODE["late"]) if dC is None else dC
    return (1.0 - frac) * dC * K.D_CU / J
