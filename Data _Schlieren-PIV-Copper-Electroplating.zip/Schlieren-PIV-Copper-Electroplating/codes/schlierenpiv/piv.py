"""Synthetic PIV images and a multi-pass FFT cross-correlation PIV.

This is a compact re-implementation of the algorithm described in Section 4.5 (64 -> 32 px
interrogation windows, 50 % overlap, Gaussian 3-point sub-pixel peak, outlier validation). It is
NOT PIVlab and will not give identical numbers; it exists so that the processing chain can be run
and tested against a known velocity field.
"""
import numpy as np
from scipy.ndimage import map_coordinates, median_filter
from . import constants as K


# ---------------------------------------------------------------- image synthesis
def render_particles(shape, xy, amp, sigma=K.PARTICLE_SIGMA_PX):
    """Gaussian particle images. xy: (N, 2) positions in pixels (x, y), amp: (N,)."""
    ny, nx = shape
    img = np.zeros(shape, np.float64)
    r = int(np.ceil(3 * sigma))
    offs = np.arange(-r, r + 1)
    x0 = np.round(xy[:, 0]).astype(int)
    y0 = np.round(xy[:, 1]).astype(int)
    for dy in offs:
        for dx in offs:
            xi, yi = x0 + dx, y0 + dy
            m = (xi >= 0) & (xi < nx) & (yi >= 0) & (yi < ny)
            w = amp[m] * np.exp(-((xi[m] - xy[m, 0]) ** 2 + (yi[m] - xy[m, 1]) ** 2) / (2 * sigma ** 2))
            np.add.at(img, (yi[m], xi[m]), w)
    return img


def make_image_pair(shape, velocity, dt=K.DT_PIV, C=K.PIXEL, ppp=K.PARTICLES_PER_PIXEL,
                    noise=2.0, rng=None, uniform_shift=None):
    """Two frames of particles advected by `velocity(x_mm, y_mm) -> (u, v) in m/s`.

    Positions advance with a midpoint (RK2) step. If uniform_shift=(dx, dy) in pixels is given the
    velocity field is ignored (used for the sub-pixel accuracy study). Returns (img1, img2, truth)
    where truth holds the particle positions."""
    rng = np.random.default_rng() if rng is None else rng
    ny, nx = shape
    pad = 24
    n = int(ppp * (nx + 2 * pad) * (ny + 2 * pad))
    p0 = np.column_stack([rng.uniform(-pad, nx + pad, n), rng.uniform(-pad, ny + pad, n)])
    amp = rng.uniform(80, 220, n)
    if uniform_shift is not None:
        p1 = p0 + np.asarray(uniform_shift, float)
    else:
        def disp(p, h):
            u, v = velocity(p[:, 0] * C * 1e3, p[:, 1] * C * 1e3)
            return np.column_stack([u, v]) * h / C
        mid = p0 + 0.5 * disp(p0, dt)
        p1 = p0 + disp(mid, dt)
    f = lambda p: render_particles(shape, p, amp) + rng.normal(0, noise, shape) + 10.0
    return f(p0), f(p1), dict(p0=p0, p1=p1)


# ---------------------------------------------------------------- correlation
def _subpixel(c, i, j):
    """Gaussian 3-point peak fit around integer peak (i = row, j = col) of correlation plane c."""
    def g(a, b, cc):
        a, b, cc = np.log(max(a, 1e-12)), np.log(max(b, 1e-12)), np.log(max(cc, 1e-12))
        den = 2 * (a + cc - 2 * b)
        return 0.0 if den == 0 else (a - cc) / den
    ny, nx = c.shape
    if 0 < i < ny - 1 and 0 < j < nx - 1 and c[i, j] > 0 and c[i - 1, j] > 0 and c[i + 1, j] > 0 \
            and c[i, j - 1] > 0 and c[i, j + 1] > 0:
        return g(c[i, j - 1], c[i, j], c[i, j + 1]), g(c[i - 1, j], c[i, j], c[i + 1, j])
    return 0.0, 0.0


def _pass(img1, img2, win, step, shift_u=None, shift_v=None, gx=None, gy=None):
    ny, nx = img1.shape
    xs = np.arange(0, nx - win + 1, step)
    ys = np.arange(0, ny - win + 1, step)
    U = np.zeros((len(ys), len(xs))); V = np.zeros_like(U); Q = np.zeros_like(U)
    hann = np.outer(np.hanning(win + 2)[1:-1], np.hanning(win + 2)[1:-1])
    for a, y0 in enumerate(ys):
        for b, x0 in enumerate(xs):
            su = 0 if shift_u is None else int(np.round(shift_u[a, b]))
            sv = 0 if shift_v is None else int(np.round(shift_v[a, b]))
            w1 = img1[y0:y0 + win, x0:x0 + win]
            ya, xa = y0 + sv, x0 + su
            if ya < 0 or xa < 0 or ya + win > ny or xa + win > nx:
                w2 = np.zeros_like(w1)
                yy0, yy1 = max(ya, 0), min(ya + win, ny)
                xx0, xx1 = max(xa, 0), min(xa + win, nx)
                if yy1 > yy0 and xx1 > xx0:
                    w2[yy0 - ya:yy1 - ya, xx0 - xa:xx1 - xa] = img2[yy0:yy1, xx0:xx1]
            else:
                w2 = img2[ya:ya + win, xa:xa + win]
            a1 = (w1 - w1.mean()) * hann
            a2 = (w2 - w2.mean()) * hann
            F = np.fft.rfft2(a1).conj() * np.fft.rfft2(a2)
            c = np.fft.fftshift(np.fft.irfft2(F, s=a1.shape))
            c = c - c.min()
            cc = win // 2
            lim = win // 2 - 2
            sub = np.zeros_like(c); sub[cc - lim:cc + lim + 1, cc - lim:cc + lim + 1] = c[cc - lim:cc + lim + 1, cc - lim:cc + lim + 1]
            i, j = np.unravel_index(np.argmax(sub), sub.shape)
            dx, dy = _subpixel(sub, i, j)
            U[a, b] = (j - cc) + dx + su
            V[a, b] = (i - cc) + dy + sv
            flat = np.sort(sub.ravel())
            Q[a, b] = sub[i, j] / max(flat[-2000] if flat.size > 2000 else flat[len(flat) // 2], 1e-9)
    return xs + win / 2.0, ys + win / 2.0, U, V, Q


def validate(U, V, thresh=2.0, eps=0.1):
    """Normalised median test (Westerweel and Scarano). Returns boolean mask of rejected vectors."""
    bad = np.zeros(U.shape, bool)
    for F in (U, V):
        pad = np.pad(F, 1, mode="edge")
        for a in range(F.shape[0]):
            for b in range(F.shape[1]):
                nb = np.delete(pad[a:a + 3, b:b + 3].ravel(), 4)
                med = np.median(nb)
                r = np.median(np.abs(nb - med))
                if abs(F[a, b] - med) / (r + eps) > thresh:
                    bad[a, b] = True
    return bad


def _fill(F, bad):
    G = F.copy()
    G[bad] = np.nan
    pad = np.pad(G, 1, mode="edge")
    for a, b in zip(*np.where(bad)):
        nb = pad[a:a + 3, b:b + 3].ravel()
        nb = nb[~np.isnan(nb)]
        G[a, b] = np.median(nb) if nb.size else 0.0
    return G


def multipass_piv(img1, img2, windows=(K.WINDOW_FIRST, K.WINDOW_FINAL), overlap=K.OVERLAP,
                  dt=K.DT_PIV, C=K.PIXEL, validate_each=True):
    """Multi-pass PIV with window shifting. Returns dict(x_mm, y_mm, u, v in m/s, displacement px, outliers)."""
    su = sv = None
    px = py = None
    for k, win in enumerate(windows):
        step = int(win * (1 - overlap))
        if su is not None:                                   # interpolate previous pass onto the new grid
            xs = np.arange(0, img1.shape[1] - win + 1, step) + win / 2.0
            ys = np.arange(0, img1.shape[0] - win + 1, step) + win / 2.0
            ix = np.interp(xs, px, np.arange(len(px))); iy = np.interp(ys, py, np.arange(len(py)))
            gx, gy = np.meshgrid(ix, iy)
            su_n = map_coordinates(su, [gy, gx], order=1, mode="nearest")
            sv_n = map_coordinates(sv, [gy, gx], order=1, mode="nearest")
        else:
            su_n = sv_n = None
        px, py, U, V, Q = _pass(img1, img2, win, step, su_n, sv_n)
        bad = validate(U, V) if validate_each else np.zeros(U.shape, bool)
        U, V = _fill(U, bad), _fill(V, bad)
        su, sv = U, V
    return dict(x_mm=px * C * 1e3, y_mm=py * C * 1e3, u=U * C / dt, v=V * C / dt, dx_px=U, dy_px=V,
                outliers=bad, quality=Q)
