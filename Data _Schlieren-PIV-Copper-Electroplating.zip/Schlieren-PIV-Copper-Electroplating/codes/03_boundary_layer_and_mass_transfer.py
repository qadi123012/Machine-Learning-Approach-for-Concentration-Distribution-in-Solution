"""Boundary-layer thickness, wall concentration and km: what the optical chain can and cannot recover.

A. Analytic: for each profile shape, the delta99 that carries exactly the Faraday flux, and the wall
   flux implied by the manuscript's late-stage delta_c = 0.75 mm.
B. Simulation: stand-in fields (3 stages x 3 shapes) -> Schlieren chain -> delta, Cs, km.
C. Dynamic-range sweep: how the result depends on the (assumed) focal length / gradient limit.

Outputs: concentration/data/profile_shape_analysis.csv, concentration/simulations/
         boundary_layer_recovery.csv, S4_boundary_layer_profiles.png, S5_dynamic_range_sweep.png
"""
import sys, pathlib, csv, argparse
HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import warnings
warnings.filterwarnings('ignore', category=RuntimeWarning)
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from schlierenpiv import constants as K, fields as F, schlieren as S, boundary_layer as B, transport as T

ap = argparse.ArgumentParser()
ap.add_argument("--seed", type=int, default=5)
args = ap.parse_args()
conc = HERE.parent / "concentration"
sim = conc / "simulations"
SHAPES = ("film", "erf", "exp")
ROWS = slice(150, 210)                       # mid-height band (y = 18.75 to 26.25 mm)

# ------------------------------------------------------------------ A. analytic table
J = T.j_faraday()
dC = K.CB - K.C_CATHODE["late"]
rowsA = []
for sh in SHAPES:
    s0 = F.wall_slope(sh)
    d99_far = K.D_CU * dC * s0 / J                                  # delta99 that carries J_Faraday
    flux_at_paper = K.D_CU * dC * s0 / K.DELTA_C["late"]            # wall flux if delta99 = 0.75 mm
    rowsA.append((sh, s0, d99_far * 1e3, T.km_film(d99_far), T.km_film(d99_far) / T.km_required(dC),
                  flux_at_paper, flux_at_paper / J))
with open(conc / "data" / "profile_shape_analysis.csv", "w", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["profile_shape", "wall_slope_ds_deta", "delta99_for_J_Faraday_mm", "km_opt_from_that_delta_m_s",
                "km_opt_over_km_req", "wall_flux_if_delta99_is_0.75mm_kg_m2_s", "that_flux_over_J_Faraday"])
    for r in rowsA:
        w.writerow([r[0], f"{r[1]:.4f}", f"{r[2]:.4f}", f"{r[3]:.4e}", f"{r[4]:.4f}", f"{r[5]:.4e}", f"{r[6]:.4f}"])
print("A. profile-shape table")
for r in rowsA:
    print(f"   {r[0]:5s} slope {r[1]:.3f}  delta99(J_F) {r[2]:.3f} mm  km,opt/km,req {r[4]:.3f}  flux at 0.75 mm = {r[6]:.2f} x J_F")
print(f"   lower bound for any concave profile: {B.minimum_delta99_for_flux()*1e3:.3f} mm (paper: 0.75 +/- 0.08 mm)")

# ------------------------------------------------------------------ B. simulation
def analyse(stage, shape, opt, seed):
    fld = F.make_concentration(stage, shape)
    r = S.run_chain(fld, opt, np.random.default_rng(seed), method="spline")
    x = fld["x_px"]; dist = B.wall_distance(x, "cathode")
    Ch = r["C_hat"][ROWS]
    cnt = np.isfinite(Ch).sum(axis=0)
    Cm = np.where(cnt > 0.9 * Ch.shape[0], np.nanmean(Ch, axis=0), np.nan)
    vrow = r["valid"][ROWS].mean(axis=0) > 0.5
    # truth on the fine grid
    xf = fld["x"]; distf = B.wall_distance(xf, "cathode"); Ctf = fld["C_proj"][ROWS].mean(axis=0)
    d_true = B.delta99(distf, Ctf, "cathode")
    Cs_true = float(Ctf[np.argmin(distf)])
    sat = B.saturation_edge(dist, vrow)
    Cs_lin = B.extrapolate_linear(dist, Cm)
    Cs_exp, lam = B.extrapolate_exponential(dist, Cm, "cathode")
    return dict(stage=stage, shape=shape, valid_fraction=float(r["valid"].mean()),
                delta99_true_mm=d_true * 1e3, saturation_edge_mm=sat * 1e3, saturation_edge_px=sat / K.PIXEL,
                Cs_true=Cs_true, Cs_linear=Cs_lin, Cs_expfit=Cs_exp,
                km_from_true_delta=T.km_film(d_true), km_from_saturation_edge=T.km_film(sat),
                _fld=fld, _r=r, _dist=dist, _Cm=Cm, _distf=distf, _Ctf=Ctf)

opt = S.Optics()
resB = [analyse(st, sh, opt, args.seed) for st in K.STAGES for sh in SHAPES]
cols = ["stage", "shape", "valid_fraction", "delta99_true_mm", "saturation_edge_mm", "saturation_edge_px",
        "Cs_true", "Cs_linear", "Cs_expfit", "km_from_true_delta", "km_from_saturation_edge"]
with open(sim / "boundary_layer_recovery.csv", "w", newline="") as fh:
    w = csv.writer(fh); w.writerow(cols)
    for d in resB:
        w.writerow([d[c] if isinstance(d[c], str) else ("" if d[c] != d[c] else f"{d[c]:.5g}") for c in cols])
print("\nB. recovery (mid-height, cathode side)")
print("   stage      shape  valid  d99true  satEdge(px)  Cs_true  Cs_lin  Cs_exp")
for d in resB:
    print(f"   {d['stage']:9s} {d['shape']:5s} {d['valid_fraction']:.3f} {d['delta99_true_mm']:7.3f} {d['saturation_edge_mm']:7.3f}({d['saturation_edge_px']:.1f})"
          f" {d['Cs_true']:8.1f} {d['Cs_linear']:7.1f} {d['Cs_expfit']:7.1f}")

# figure S4 (late stage)
fig, ax = plt.subplots(1, 3, figsize=(15, 4.6), sharey=True)
for a, sh in zip(ax, SHAPES):
    d = [q for q in resB if q["stage"] == "late" and q["shape"] == sh][0]
    a.plot(d["_distf"] * 1e3, d["_Ctf"], "k", label="truth (depth-averaged)")
    a.plot(d["_dist"] * 1e3, d["_Cm"], "ro", ms=4, label="reconstructed (valid pixels)")
    a.axvspan(0, d["saturation_edge_mm"], color="r", alpha=.1, label="saturated wall band")
    a.axhline(K.CB, color="0.6", ls=":")
    if d["Cs_linear"] == d["Cs_linear"]:
        a.plot(0, d["Cs_linear"], "bs", label=f"linear extrapolation Cs = {d['Cs_linear']:.0f}")
    if d["Cs_expfit"] == d["Cs_expfit"]:
        a.plot(0, d["Cs_expfit"], "g^", label=f"exponential fit Cs = {d['Cs_expfit']:.0f}")
    a.plot(0, d["Cs_true"], "kx", ms=9, label=f"true Cs = {d['Cs_true']:.0f}")
    a.set_xlim(-0.1, 3.0); a.set_xlabel("distance from the cathode (mm)")
    a.set_title(f"profile shape: {sh}  (delta99 true = {d['delta99_true_mm']:.2f} mm)"); a.legend(fontsize=7, loc="lower right"); a.grid(alpha=.3)
ax[0].set_ylabel("Cu2+ (kg/m3)")
fig.suptitle("Late stage: what survives the knife-edge range near the cathode (SIMULATION; focal length assumed)")
fig.tight_layout(); fig.savefig(sim / "S4_boundary_layer_profiles.png", dpi=150); plt.close(fig)

# ------------------------------------------------------------------ C. dynamic-range sweep
fs = np.geomspace(0.003, 0.3, 14)
sweep = []
for f in fs:
    o = S.Optics(f=float(f))
    row = {"f_m": f, "gradient_limit_kg_m3_per_mm": o.gradient_limit(0.9e-3) * 1e-3}
    for sh in ("film", "exp"):
        d = analyse("late", sh, o, args.seed)
        r = d["_r"]
        within_row = np.nanstd((r["C_hat"] - d["_fld"]["C_proj_px"])[ROWS][:, 70:90], axis=1).mean()
        row[f"valid_{sh}"] = d["valid_fraction"]
        row[f"Cs_err_lin_{sh}"] = d["Cs_linear"] - d["Cs_true"]
        row[f"Cs_err_exp_{sh}"] = d["Cs_expfit"] - d["Cs_true"] if d["Cs_expfit"] == d["Cs_expfit"] else np.nan
        row[f"noise_{sh}"] = within_row
    sweep.append(row)
with open(sim / "dynamic_range_sweep.csv", "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(sweep[0].keys())); w.writeheader()
    for r in sweep:
        w.writerow({k: f"{v:.5g}" for k, v in r.items()})
fig, ax = plt.subplots(1, 3, figsize=(15, 4.4))
gl = [r["gradient_limit_kg_m3_per_mm"] for r in sweep]
for sh, c in (("film", "C0"), ("exp", "C1")):
    ax[0].semilogx(gl, [100 * r[f"valid_{sh}"] for r in sweep], "o-", color=c, label=sh)
    ax[1].semilogx(gl, [r[f"Cs_err_lin_{sh}"] for r in sweep], "s-", color=c, label=f"{sh}: linear")
    ax[1].semilogx(gl, [r[f"Cs_err_exp_{sh}"] if abs(r[f"Cs_err_exp_{sh}"]) < 100 else np.nan for r in sweep], "^--", color=c, label=f"{sh}: exponential fit (|error| > 100 omitted)")
    ax[2].loglog(gl, [r[f"noise_{sh}"] for r in sweep], "o-", color=c, label=sh)
for a in ax:
    a.axvline(S.Optics().gradient_limit(0.9e-3) * 1e-3, color="k", ls=":", label="assumed f = 0.10 m"); a.grid(alpha=.3)
    a.set_xlabel("largest measurable |dC/dx| (kg/m3 per mm)  [a_max = 0.9 mm]")
ax[0].set_ylabel("valid pixels (%)"); ax[0].set_title("(a) valid-pixel fraction"); ax[0].legend()
ax[1].set_ylabel("Cs estimate minus truth (kg/m3)"); ax[1].set_ylim(-100, 100); ax[1].set_title("(b) cathode wall concentration error"); ax[1].legend(fontsize=7)
ax[2].set_ylabel("row-to-row noise of reconstructed C (kg/m3)"); ax[2].set_title("(c) price of a wide range: noise"); ax[2].legend()
fig.suptitle("Trade-off between dynamic range and sensitivity (SIMULATION, late stage)")
fig.tight_layout(); fig.savefig(sim / "S5_dynamic_range_sweep.png", dpi=150); plt.close(fig)
print("\nC. gradient limit at the assumed f = 0.10 m: %.2f kg/m3 per mm; film-profile wall gradient %.0f kg/m3 per mm"
      % (S.Optics().gradient_limit(0.9e-3) * 1e-3, dC / K.DELTA_C['late'] * 1e-3))
print("   focal length that would keep the film wall gradient in range: %.1f mm" %
      (0.1 * S.Optics().gradient_limit(0.9e-3) / (dC / K.DELTA_C['late']) * 1e3))
