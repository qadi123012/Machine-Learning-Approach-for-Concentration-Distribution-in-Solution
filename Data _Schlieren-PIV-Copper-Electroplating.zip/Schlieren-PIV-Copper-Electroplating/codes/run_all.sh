#!/usr/bin/env bash
# Regenerate every table, simulation and figure. Takes about a minute on one CPU core.
# Run from anywhere:  bash codes/run_all.sh
set -euo pipefail
cd "$(dirname "$0")"
python -m pytest -q tests
python 01_transport_numbers.py            > ../concentration/simulations/log_01_transport_numbers.txt
python 02_schlieren_calibration_and_reconstruction.py > ../concentration/simulations/log_02_reconstruction.txt
python 03_boundary_layer_and_mass_transfer.py > ../concentration/simulations/log_03_boundary_layer.txt
python 04_piv_simulation.py               > ../PIV/simulations/log_04_piv.txt
python 05_coupled_overlay.py              > ../PIV/simulations/log_05_coupled.txt
python 06_preprocessing_effect.py         > ../concentration/simulations/log_06_preprocessing.txt
echo "Done. See concentration/simulations and PIV/simulations."
