"""Coupled concentration + velocity (Schlieren + PIV) on the 2.0 mm vector grid, and the effect of
the 0.12 mm inter-channel registration residual. Late stage, simulated.

Output: PIV/simulations/P5_coupled_concentration_velocity.png (copy in concentration/simulations/S7_...),
        coupled_registration_metrics.json
"""
import sys, pathlib, json, shutil
HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import numpy as np
from scipy.ndimage import map_coordinates
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from schlierenpiv import constants as K, fields as F, schlieren as S, piv as P

root = HERE.parent
SHAPE = (360, 160)
opt = S.Optics()
fld = F.make_concentration("late", "erf")
r = S.run_chain(fld, opt, np.random.default_rng(21), method="spline")
vel = F.velocity_field("late")
a, b, _ = P.make_image_pair(SHAPE, vel, rng=np.random.default_rng(22))
pv = P.multipass_piv(a, b)

Chat = r["C_hat"]; Ct = fld["C_proj_px"]
def sample(Cmap, xmm, ymm):
    ix = xmm / (K.PIXEL * 1e3) - 0.5
    iy = ymm / (K.PIXEL * 1e3) - 0.5
    Xg, Yg = np.meshgrid(ix, iy)
    filled = np.where(np.isnan(Cmap), np.nan, Cmap)
    return map_coordinates(np.nan_to_num(filled, nan=-999.0), [Yg, Xg], order=1, mode="nearest")

Cn = sample(Chat, pv["x_mm"], pv["y_mm"])
Cn = np.where(Cn < -900, np.nan, Cn)
# registration residual: shift the concentration map by 0.12 mm (about 1 pixel) along x and compare at the vector nodes
shift_px = K.REGISTRATION_RESIDUAL / K.PIXEL
Cs_shift = sample(np.roll(Ct, int(round(shift_px)), axis=1), pv["x_mm"], pv["y_mm"])
C0 = sample(Ct, pv["x_mm"], pv["y_mm"])
dC = np.abs(Cs_shift - C0)
X = np.meshgrid(pv["x_mm"], pv["y_mm"])[0]
near_wall = (X < 2.5) | (X > 17.5)
met = dict(shift_mm=K.REGISTRATION_RESIDUAL * 1e3, shift_px=float(shift_px),
           max_dC_near_walls_kg_m3=float(dC[near_wall].max()), rms_dC_near_walls_kg_m3=float(np.sqrt(np.mean(dC[near_wall] ** 2))),
           max_dC_bulk_kg_m3=float(dC[~near_wall].max()), rms_dC_bulk_kg_m3=float(np.sqrt(np.mean(dC[~near_wall] ** 2))),
           quoted_concentration_precision_2sigma=K.CONC_PRECISION_2SIGMA,
           nearest_vector_to_electrode_mm=float(min(pv["x_mm"].min(), K.GAP * 1e3 - pv["x_mm"].max())),
           note="shift applied to the TRUE depth-averaged field. The nearest PIV vector is about 2 mm from an electrode, outside the 0.75 to 1 mm boundary layer, so the grid never samples the layer itself")
json.dump(met, open(root / "PIV" / "simulations" / "coupled_registration_metrics.json", "w"), indent=2)
print(json.dumps(met, indent=2))

fig, ax = plt.subplots(1, 2, figsize=(12, 9), gridspec_kw=dict(width_ratios=[1, 1]))
ext = [0, 20, 0, 45]
m = ax[0].imshow(Chat, origin="lower", extent=ext, cmap="RdYlBu_r", vmin=0, vmax=165, aspect="equal")
ax[0].quiver(pv["x_mm"], pv["y_mm"], pv["u"], pv["v"], color="k", angles="xy", scale_units="xy", scale=0.0032, width=0.005)
ax[0].set_title("Schlieren concentration (white = saturated band)\nwith PIV vectors on the 2.0 mm grid")
ax[0].set_xlabel("x (mm): anode 0, cathode 20"); ax[0].set_ylabel("y (mm)")
fig.colorbar(m, ax=ax[0], shrink=0.6, label="Cu2+ (kg/m3)")
sp = np.hypot(pv["u"], pv["v"]) * 1e3
mm = ax[1].pcolormesh(pv["x_mm"], pv["y_mm"], sp, cmap="viridis", shading="nearest")
cs = ax[1].contour(*np.meshgrid(fld["x_px"] * 1e3, (np.arange(360) + 0.5) * K.PIXEL * 1e3), Ct, levels=[60, 80, 90, 110, 130], colors="w", linewidths=.8)
ax[1].clabel(cs, fmt="%d", fontsize=7)
ax[1].set_title("PIV speed (mm/s) with concentration contours (kg/m3)")
ax[1].set_xlabel("x (mm)"); ax[1].set_aspect("equal")
fig.colorbar(mm, ax=ax[1], shrink=0.6, label="speed (mm/s)")
fig.suptitle("Coupled fields after co-registration (SIMULATION, stage 3)")
fig.tight_layout()
p = root / "PIV" / "simulations" / "P5_coupled_concentration_velocity.png"
fig.savefig(p, dpi=140); plt.close(fig)
shutil.copy(p, root / "concentration" / "simulations" / "S7_coupled_concentration_velocity.png")
