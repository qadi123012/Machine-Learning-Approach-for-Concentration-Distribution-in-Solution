"""PIV simulation: synthetic particle images from stand-in velocity fields, recovered by multi-pass PIV.

Stand-in fields are divergence-free counter-clockwise rolls scaled to the peak speeds quoted in the
manuscript (4.1, 6.6 and 8.0 mm/s). They are NOT measurements. Settings follow Section 4.5:
0.125 mm/pixel, dt = 0.1 s, 64 -> 32 px windows, 50 % overlap, 2.0 mm vector spacing.

Outputs (PIV/simulations/): P1_particle_image_pair.png, P2_stage_velocity_fields.png,
P3_gap_velocity_profiles.png, P4_displacement_accuracy.png, piv_metrics.json, displacement_accuracy.csv
"""
import sys, pathlib, json, csv, argparse
HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import numpy as np
from scipy.ndimage import uniform_filter
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from schlierenpiv import constants as K, fields as F, piv as P, transport as T

ap = argparse.ArgumentParser()
ap.add_argument("--out", default=str(HERE.parent / "PIV" / "simulations"))
ap.add_argument("--n_seeds", type=int, default=20)
args = ap.parse_args()
out = pathlib.Path(args.out); out.mkdir(parents=True, exist_ok=True)
SHAPE = (360, 160)                                    # 45 mm x 20 mm at 0.125 mm/pixel
xx_px, yy_px = np.meshgrid(np.arange(SHAPE[1]) + 0.5, np.arange(SHAPE[0]) + 0.5)
metrics = {}

# ------------------------------------------------------------------ stage fields, repeated seedings
store = {}
for stage in K.STAGES:
    vel = F.velocity_field(stage)
    ut_img, vt_img = vel(xx_px * K.PIXEL * 1e3, yy_px * K.PIXEL * 1e3)
    uav = uniform_filter(ut_img, K.WINDOW_FINAL, mode="nearest"); vav = uniform_filter(vt_img, K.WINDOW_FINAL, mode="nearest")
    runs = []
    for s in range(args.n_seeds):
        rng = np.random.default_rng(1000 + s)
        a, b, _ = P.make_image_pair(SHAPE, vel, rng=rng)
        r = P.multipass_piv(a, b)
        runs.append(r)
        if s == 0:
            first = (a, b, r)
    r0 = runs[0]
    gx = np.round(r0["x_mm"] / (K.PIXEL * 1e3) - 0.5).astype(int); gy = np.round(r0["y_mm"] / (K.PIXEL * 1e3) - 0.5).astype(int)
    X, Y = np.meshgrid(r0["x_mm"], r0["y_mm"])
    ut, vt = vel(X, Y)                                # point truth at window centre
    ua, va = uav[np.ix_(gy, gx)], vav[np.ix_(gy, gx)]  # window-averaged truth
    U = np.stack([q["u"] for q in runs]); V = np.stack([q["v"] for q in runs])
    rmse_pt = np.sqrt(np.mean((U - ut) ** 2 + (V - vt) ** 2) / 2) * 1e3
    rmse_avg = np.sqrt(np.mean((U - ua) ** 2 + (V - va) ** 2) / 2) * 1e3
    rms_speed = np.sqrt(np.mean(ut ** 2 + vt ** 2)) * 1e3
    speed = np.hypot(U, V)
    metrics[stage] = dict(
        n_vectors=int(U[0].size), n_seedings=args.n_seeds,
        truth_peak_speed_mm_s=float(np.hypot(ut_img, vt_img).max() * 1e3),
        truth_min_speed_mm_s=float(np.hypot(ut, vt).min() * 1e3),
        piv_peak_speed_mean_mm_s=float(speed.max(axis=(1, 2)).mean() * 1e3),
        rmse_vs_point_truth_mm_s=float(rmse_pt),
        rmse_vs_window_averaged_truth_mm_s=float(rmse_avg),
        rms_speed_mm_s=float(rms_speed),
        relative_rmse_vs_point_truth_percent=float(100 * rmse_pt / rms_speed),
        relative_rmse_vs_window_averaged_truth_percent=float(100 * rmse_avg / rms_speed),
        outlier_fraction=float(np.mean([q["outliers"].mean() for q in runs])),
        max_true_displacement_px=float(T.displacement_px(np.hypot(ut_img, vt_img).max())),
    )
    store[stage] = dict(first=first, X=X, Y=Y, ut=ut, vt=vt, ua=ua, va=va, U=U, V=V)
    print(stage, {k: round(v, 3) if isinstance(v, float) else v for k, v in metrics[stage].items()})

# ------------------------------------------------------------------ P1: image pair
a, b, _ = store["late"]["first"]
fig, ax = plt.subplots(1, 3, figsize=(14, 5.2))
crop = (slice(100, 190), slice(0, 90))
ax[0].imshow(a[crop], cmap="gray", origin="lower"); ax[0].set_title("frame n (crop, 90 x 90 px)")
ax[1].imshow(b[crop], cmap="gray", origin="lower"); ax[1].set_title("frame n+4 (dt = 100 ms)")
ax[2].imshow(a[crop], cmap="Reds", origin="lower", alpha=.6); ax[2].imshow(b[crop], cmap="Blues", origin="lower", alpha=.5)
ax[2].set_title("overlay: red = n, blue = n+4")
fig.suptitle("Synthetic particle images, stage 3 (10 um tracers, 0.04 particles per pixel). SIMULATION")
fig.tight_layout(); fig.savefig(out / "P1_particle_image_pair.png", dpi=150); plt.close(fig)

# ------------------------------------------------------------------ P2: stage fields
fig, ax = plt.subplots(2, 3, figsize=(14, 12))
for k, stage in enumerate(K.STAGES):
    d = store[stage]; r = d["first"][2]
    sp_t = np.hypot(d["ut"], d["vt"]) * 1e3
    ax[0, k].pcolormesh(d["X"], d["Y"], sp_t, cmap="viridis", vmin=0, vmax=8.2, shading="nearest")
    q = max(1, 1)
    ax[0, k].quiver(d["X"], d["Y"], d["ut"], d["vt"], color="w", angles="xy", scale_units="xy", scale=0.0032, width=0.006)
    ax[0, k].set_title(f"{K.STAGE_LABELS[stage]}\nstand-in truth, peak {metrics[stage]['truth_peak_speed_mm_s']:.1f} mm/s", fontsize=10)
    sp_p = np.hypot(r["u"], r["v"]) * 1e3
    m = ax[1, k].pcolormesh(r["x_mm"], r["y_mm"], sp_p, cmap="viridis", vmin=0, vmax=8.2, shading="nearest")
    ax[1, k].quiver(r["x_mm"], r["y_mm"], r["u"], r["v"], color="w", angles="xy", scale_units="xy", scale=0.0032, width=0.006)
    ax[1, k].set_title(f"PIV result, RMSE {metrics[stage]['rmse_vs_point_truth_mm_s']:.2f} mm/s "
                       f"({metrics[stage]['relative_rmse_vs_point_truth_percent']:.1f} %)", fontsize=10)
    for a_ in ax[:, k]:
        a_.set_xlabel("x (mm): anode 0, cathode 20"); a_.set_ylabel("y (mm)"); a_.set_aspect("equal")
fig.colorbar(m, ax=ax.ravel().tolist(), shrink=0.5, label="speed (mm/s)")
fig.suptitle("PIV recovery of counter-clockwise rolls on the 2.0 mm vector grid (SIMULATION)")
fig.savefig(out / "P2_stage_velocity_fields.png", dpi=140); plt.close(fig)

# ------------------------------------------------------------------ P3: gap profiles
fig, ax = plt.subplots(1, 3, figsize=(15, 4.4), sharey=False)
for k, stage in enumerate(K.STAGES):
    d = store[stage]
    mid = slice(d["X"].shape[0] // 2 - 3, d["X"].shape[0] // 2 + 4)       # rows around mid-height
    xg = d["X"][0]
    truth = np.hypot(d["ut"], d["vt"])[mid].mean(axis=0) * 1e3
    sp = np.hypot(d["U"], d["V"])[:, mid].mean(axis=1) * 1e3              # (seeds, nx)
    ax[k].plot(xg, truth, "k-", label="stand-in truth")
    ax[k].errorbar(xg, sp.mean(axis=0), yerr=sp.std(axis=0), fmt="o--", capsize=3, label="PIV (mean +/- sd, 20 seedings)")
    ax[k].set_xlabel("x across the gap (mm): anode 0, cathode 20"); ax[k].set_ylabel("|V| (mm/s)")
    ax[k].set_title(K.STAGE_LABELS[stage]); ax[k].grid(alpha=.3); ax[k].legend(fontsize=8)
fig.suptitle("Velocity-magnitude profile across the 20 mm gap at mid-height (cf. manuscript Fig. 14). SIMULATION")
fig.tight_layout(); fig.savefig(out / "P3_gap_velocity_profiles.png", dpi=150); plt.close(fig)

# ------------------------------------------------------------------ P4: displacement accuracy
disp = [0.2, 0.4, 0.64, 1.0, 1.5, 2.5, 4.0, 5.28, 6.4, 8.0]
rows = []
for d_ in disp:
    errs = []
    for s in range(args.n_seeds):
        rng = np.random.default_rng(5000 + s)
        ang = rng.uniform(0, 2 * np.pi)
        sh = (d_ * np.cos(ang), d_ * np.sin(ang))
        a, b, _ = P.make_image_pair(SHAPE, None, rng=rng, uniform_shift=sh)
        r = P.multipass_piv(a, b)
        errs.append(np.hypot(r["dx_px"] - sh[0], r["dy_px"] - sh[1]).ravel())
    e = np.concatenate(errs)
    rows.append((d_, np.sqrt(np.mean(e ** 2)), np.median(e), np.percentile(e, 95)))
with open(out / "displacement_accuracy.csv", "w", newline="") as fh:
    w = csv.writer(fh); w.writerow(["true_displacement_px", "rms_error_px", "median_error_px", "p95_error_px",
                                    "equivalent_velocity_mm_s", "rms_error_mm_s", "rms_error_percent_of_displacement"])
    for d_, rm, md, p95 in rows:
        w.writerow([d_, f"{rm:.4f}", f"{md:.4f}", f"{p95:.4f}", f"{d_*K.PIXEL/K.DT_PIV*1e3:.3f}",
                    f"{rm*K.PIXEL/K.DT_PIV*1e3:.4f}", f"{100*rm/d_:.2f}"])
darr = np.array([r[0] for r in rows]); rm = np.array([r[1] for r in rows])
fig, ax = plt.subplots(1, 2, figsize=(12, 4.4))
ax[0].loglog(darr, rm, "o-", label="RMS error"); ax[0].loglog(darr, [r[3] for r in rows], "s--", label="95th percentile")
for v, lab in ((0.64, "0.8 mm/s"), (5.28, "6.6 mm/s"), (6.4, "8.0 mm/s")):
    ax[0].axvline(v, color="0.6", ls=":"); ax[0].text(v, ax[0].get_ylim()[0] * 1.5, lab, rotation=90, fontsize=8)
ax[0].set_xlabel("true displacement (px)"); ax[0].set_ylabel("displacement error (px)"); ax[0].legend(); ax[0].grid(alpha=.3, which="both")
ax[0].set_title("(a) absolute error")
ax[1].semilogx(darr, 100 * rm / darr, "o-"); ax[1].axhline(2.1, color="r", ls="--", label="manuscript uncertainty, 2.1 %")
ax[1].set_xlabel("true displacement (px)"); ax[1].set_ylabel("RMS error / displacement (%)"); ax[1].legend(); ax[1].grid(alpha=.3, which="both")
ax[1].set_title("(b) relative error")
fig.suptitle("Sub-pixel accuracy of the multi-pass correlation (uniform translations, SIMULATION)")
fig.tight_layout(); fig.savefig(out / "P4_displacement_accuracy.png", dpi=150); plt.close(fig)
metrics["displacement_study"] = {f"{d_}px": dict(rms_px=float(rm_), relative_percent=float(100 * rm_ / d_)) for d_, rm_, _, _ in rows}
json.dump(metrics, open(out / "piv_metrics.json", "w"), indent=2)
for d_, rm_, md, p95 in rows:
    print(f"disp {d_:5.2f} px  rms {rm_:.3f} px  ({100*rm_/d_:6.1f} %)  p95 {p95:.3f}")
