# codes/

All code for the project. Python 3.9 or newer; tested with 3.12.

```
codes/
├── schlierenpiv/                 the package
│   ├── constants.py              every number, tagged [paper], [derived] or [assumed]
│   ├── transport.py              Faraday flux, km, Re, Pe, Sh, Stokes number, displacement in pixels
│   ├── fields.py                 stand-in concentration and velocity fields
│   ├── schlieren.py              knife-edge forward model, calibration, inversion, integration
│   ├── boundary_layer.py         delta99, wall extrapolation, km, Faraday-flux bound
│   ├── piv.py                    synthetic particle images and multi-pass FFT PIV
│   └── preprocessing.py          quantitative pre-processing and single-channel display enhancement
├── image_enhancement.py          your import_cv2.py, cleaned and made runnable
├── 01_transport_numbers.py
├── 02_schlieren_calibration_and_reconstruction.py
├── 03_boundary_layer_and_mass_transfer.py
├── 04_piv_simulation.py
├── 05_coupled_overlay.py
├── 06_preprocessing_effect.py
├── run_all.sh
└── tests/test_schlierenpiv.py    11 tests
```

## Scripts

| Script | What it does | Main outputs |
|---|---|---|
| `01_transport_numbers.py` | recomputes every derived number in the paper and compares it with the printed value | `concentration/data/derived_transport_numbers.csv`, `PIV/data/tracer_and_flow_numbers.csv` |
| `02_...reconstruction.py` | stand-in field to simulated Schlieren frame, pixel-wise calibration, spline and linear inversion, integration to concentration | S1, S2, S3, `reconstruction_metrics.json` |
| `03_boundary_layer_...py` | profile-shape analysis, delta and Cs recovery for 3 stages x 3 shapes, dynamic-range sweep | S4, S5, three CSV files |
| `04_piv_simulation.py` | synthetic particle images, multi-pass PIV, accuracy against truth, sub-pixel study | P1 to P4, `piv_metrics.json` |
| `05_coupled_overlay.py` | concentration and vectors on one grid; effect of the 0.12 mm registration residual | P5 (copy S7) |
| `06_preprocessing_effect.py` | reconstruction error for five pre-processing choices | S6 |

`bash codes/run_all.sh` runs the tests and then all six, about a minute on one CPU core. Every script takes its random seeds from fixed values, so reruns give identical numbers.

## The Schlieren chain implemented in `schlieren.py`

```
dC/dx --(dn/dC)--> dn/dx --(L/n0)--> eps --(f)--> a --knife edge--> grey value
```

* forward: `I = g * Imax * Phi((a - dx) / sigma_s)`, with a pixel gain map `g`, read noise and 8-bit quantisation
* calibration: 10 knife positions at 0.19 mm spacing, 10 frames averaged each
* inversion: `invert_spline` (monotone cubic through each pixel's own curve) or `invert_linear` (Eq. 10, slope at the reference)
* a pixel is **valid** only if its calibration curve is monotone and the measurement lies inside the calibrated range
* `integrate_rows` integrates dC/dx outward from the central column (assumed to be at Cb) and stops at the first invalid pixel

## The PIV implemented in `piv.py`

Synthetic Gaussian particle images (0.04 per pixel, sigma 1 px), advected with a midpoint step, then 64 px then 32 px windows at 50 % overlap with integer window shifting between passes, Gaussian three-point sub-pixel fit, normalised median validation and replacement. It is not PIVlab, so absolute numbers will differ slightly from the paper's software.

## image_enhancement.py

This is the script you supplied (`import cv2.py`), with these changes only:

* `process_all_images()` was never called, so the original did nothing when run. A command-line entry point was added.
* the unused `skimage.exposure` import was removed,
* pattern, output folder, blur, CLAHE clip and tile, gamma and scale are now arguments, and grayscale images work.

The processing itself is unchanged (a test checks that it equals the single-channel version in `schlierenpiv/preprocessing.py`). It is meant for **figures and visual inspection**. It differs from Section 2.4 of the manuscript, which describes background subtraction and a median filter, not a Gaussian blur, and the 1.5x up-scaling changes the pixel scale from 0.125 to 0.0833 mm. For anything that is inverted to concentration or velocity use `quantitative_preprocess`.

```bash
python codes/image_enhancement.py --input "enhanced_frame_*.png" --output enhanced_output
```

## Tests

```bash
python -m pytest -q codes/tests
```

They check the paper's closed-form numbers, the profile shapes, spline inversion inside and outside the calibrated range, integration, delta99 and the flux bound, PIV recovery of a known shift, the velocity-field peaks and direction, and the enhancement script.

## Using your own instrument values

Edit the `[assumed]` block in `schlierenpiv/constants.py`: focal length, source-image width, noise, stratification and plume amplitude. To run on real frames, use `schlieren.invert_spline`, `schlieren.integrate_rows` and `piv.multipass_piv` directly; they take plain NumPy arrays.
