"""Recompute every derived number quoted in the manuscript and compare with the printed value.

Writes  concentration/data/derived_transport_numbers.csv
        PIV/data/tracer_and_flow_numbers.csv
Usage:  python 01_transport_numbers.py
"""
import sys, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import csv
import numpy as np
from schlierenpiv import constants as K, transport as T

rows = []   # (group, quantity, computed, quoted, unit, note)


def add(group, name, computed, quoted, unit, note=""):
    rows.append((group, name, computed, quoted, unit, note))


# ---- electrochemistry / film model ------------------------------------------------
J = T.j_faraday()
add("concentration", "J_Faraday", J, 6.09e-5, "kg m-2 s-1", "Eq. 16")
dC = K.CB - K.C_CATHODE["late"]
add("concentration", "Cb - Cs (late)", dC, 82.0, "kg m-3")
add("concentration", "km,req = J_F / (Cb-Cs)", T.km_required(dC), 7.43e-7, "m s-1", "Eq. 17")
add("concentration", "J_diff = D (Cb-Cs)/delta (late)", T.j_diffusive(dC, K.DELTA_C["late"]), 7.81e-5, "kg m-2 s-1", "Eq. 14")
for s in K.STAGES:
    add("concentration", f"km,opt = D/delta ({s})", T.km_film(K.DELTA_C[s]), K.KM_OPT_QUOTED[s], "m s-1", "Table 2")
    add("concentration", f"km* = km/km,opt(late) ({s})", T.km_film(K.DELTA_C[s]) / T.km_film(K.DELTA_C["late"]),
        K.KM_NORM_QUOTED[s], "-", "Table 2")
add("concentration", "km,opt / km,req (late)", T.km_film(K.DELTA_C["late"]) / T.km_required(dC), np.nan, "-",
    "optical estimate exceeds the Faraday requirement")
add("concentration", "J_diff / J_Faraday (late)", T.j_diffusive(dC, K.DELTA_C["late"]) / J, np.nan, "-")
add("concentration", "delta of a LINEAR film that carries exactly J_Faraday", K.D_CU * dC / J * 1e3, np.nan, "mm",
    "equals the stage-1 value 0.96 mm")
add("concentration", "lower bound of delta99 for any concave profile at J_Faraday",
    __import__("schlierenpiv.boundary_layer", fromlist=["x"]).minimum_delta99_for_flux() * 1e3, np.nan, "mm",
    "quoted late-stage delta_c = 0.75 mm lies below this bound")
add("concentration", "delta_c (late) in native Schlieren pixels", K.DELTA_C["late"] / K.PIXEL, np.nan, "px")
add("concentration", "registration residual / delta_c (late)", K.REGISTRATION_RESIDUAL / K.DELTA_C["late"], 0.16, "-")
add("concentration", "Sc = nu / D", K.NU / K.D_CU, K.SC, "-")
add("concentration", "Ra = Gr Sc", K.GR_QUOTED * K.SC, np.nan, "-",
    "above 1e9: outside the usual laminar range of Sh = 0.59 Ra^1/4")
add("concentration", "Sh = 0.59 (Gr Sc)^1/4", T.sherwood_vertical_plate(K.GR_QUOTED, K.SC), K.SH_QUOTED, "-", "Eq. 18")
add("concentration", "km,conv = Sh D / L", T.km_convective(K.SH_QUOTED), 2.98e-6, "m s-1", "Eq. 19")
add("concentration", "beta_s implied by Gr = 7.33e6", T.implied_beta_s(K.GR_QUOTED, dC), np.nan, "m3 kg-1",
    "beta_s is not stated in the manuscript")
add("concentration", "Gr for beta_s = 0.145 m3/kg (used by the earlier simulation repo)", T.grashof(0.145, dC), np.nan, "-")

# ---- flow / PIV --------------------------------------------------------------------
add("PIV", "Re (stage 1, v = 0.8 mm/s)", T.reynolds(0.8e-3), 36.0, "-")
add("PIV", "Re (stage 3, v = 6.6 mm/s)", T.reynolds(6.6e-3), 297.0, "-")
add("PIV", "Pe = vL/D (6.6 mm/s)", T.peclet(6.6e-3), 4.16e5, "-")
add("PIV", "tau_p = rho_p dp^2 / (18 mu)", T.stokes_response_time(), 5.30e-6, "s")
add("PIV", "tau_f = L / v", K.H_ELECTRODE / 6.6e-3, 6.82, "s")
add("PIV", "Stokes number", T.stokes_number(6.6e-3), 7.8e-7, "-")
add("PIV", "terminal velocity (negative = rising)", T.terminal_velocity(), -1.24e-6, "m s-1")
add("PIV", "|v_s| / 0.8 mm/s", abs(T.terminal_velocity()) / 0.8e-3 * 100, 0.155, "%")
add("PIV", "|v_s| / 5 mm/s", abs(T.terminal_velocity()) / 5e-3 * 100, 0.025, "%", "quoted as 'less than 0.025 %'")
for v, q in ((0.8e-3, 0.64), (6.6e-3, 5.28), (8.0e-3, 6.40)):
    add("PIV", f"displacement at {v*1e3:.1f} mm/s", T.displacement_px(v), q, "px", "dt = 0.1 s, C = 0.125 mm/px")
add("PIV", "vector spacing = 32 px x 50 % x 0.125 mm", K.WINDOW_FINAL * (1 - K.OVERLAP) * K.PIXEL * 1e3, 2.0, "mm")
add("PIV", "vectors across the 20 mm gap", K.GAP / K.VECTOR_SPACING, np.nan, "-")
add("PIV", "kinematic viscosity mu / rho", K.MU / K.RHO_F, K.NU, "m2 s-1")
add("PIV", "velocity uncertainty at the 2.1 % level (6.6 mm/s)", 0.021 * 6.6, np.nan, "mm/s")
add("PIV", "0.64 px displacement: velocity error for 0.05 px peak-fit error", 0.05 * K.PIXEL / K.DT_PIV * 1e3, np.nan, "mm/s")

# ---- write -----------------------------------------------------------------------
def rel(c, q):
    return abs(c - q) / abs(q) * 100 if (q == q and q != 0) else np.nan

for group, folder, fname in (("concentration", "concentration/data", "derived_transport_numbers.csv"),
                             ("PIV", "PIV/data", "tracer_and_flow_numbers.csv")):
    out = ROOT / folder / fname
    with open(out, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["quantity", "computed", "quoted_in_manuscript", "unit", "relative_difference_percent", "note"])
        for g, n, c, q, u, note in rows:
            if g == group:
                r = rel(c, q)
                w.writerow([n, f"{c:.6g}", "" if q != q else f"{q:.6g}", u, "" if r != r else f"{r:.2f}", note])
    print("wrote", out)
bad = [(n, c, q) for g, n, c, q, u, _ in rows if q == q and rel(c, q) > 1.5]
print("\nQuantities differing from the manuscript by more than 1.5 %:", bad if bad else "none")
for g, n, c, q, u, note in rows:
    print(f"{g:13s} {n[:62]:62s} {c:12.5g}  quoted {q if q==q else '-':>10}  {u}")
