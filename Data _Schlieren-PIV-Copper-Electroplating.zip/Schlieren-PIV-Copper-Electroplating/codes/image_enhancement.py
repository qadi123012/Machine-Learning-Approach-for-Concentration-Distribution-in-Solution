"""Display enhancement of Schlieren / PIV frames (cleaned version of the original import_cv2.py).

What it does, per image (unchanged from the original script):
  1. float conversion, 3 x 3 Gaussian blur
  2. CLAHE (clip limit 2.0, 8 x 8 tiles) on each colour channel
  3. gamma correction, gamma = 0.9 (brightens)
  4. 1.5x bicubic up-scaling

Changes with respect to the original file
  * `process_all_images()` was defined but never called, so running the file did nothing. A command
    line entry point was added.
  * the unused `from skimage import exposure` import was removed.
  * input pattern, output folder and all four parameters are now arguments.
  * grayscale input is handled (the original assumed 3 channels).

IMPORTANT, read before using this on data that will be inverted to concentration or velocity
  CLAHE and gamma are NON-LINEAR and, for CLAHE, image-dependent. The pixel-wise knife-edge calibration
  (Eq. 8-10) assumes grey value is a fixed function of ray displacement, so these operations must NOT be
  applied to frames that enter the quantitative inversion, unless the calibration images undergo exactly
  the same fixed point-wise transform (CLAHE does not qualify). The 1.5x up-scaling also changes the
  pixel scale from 0.125 to 0.0833 mm per pixel, so a PIV scale of C = 1.25e-4 m/pixel would no longer
  be valid for the enlarged frames. Use this script for figures and visual inspection. For the
  quantitative path use `schlierenpiv.preprocessing.quantitative_preprocess` (background subtraction and
  median filtering only). Experiment 06_preprocessing_effect.py quantifies the difference.

Usage
    python image_enhancement.py --input "enhanced_frame_*.png" --output enhanced_output
"""
import argparse
import glob
import os

import cv2
import numpy as np


def enhance_image(image_path, output_path, blur=3, clip=2.0, tile=8, gamma=0.9, scale=1.5):
    img = cv2.imread(image_path, cv2.IMREAD_UNCHANGED)
    if img is None:
        raise FileNotFoundError(image_path)
    if img.ndim == 2:
        img = img[:, :, None]
    img_float = img.astype(np.float32) / 255.0

    denoised = cv2.GaussianBlur(img_float, (blur, blur), 0)
    if denoised.ndim == 2:
        denoised = denoised[:, :, None]
    img_uint8 = (denoised * 255).astype(np.uint8)

    clahe = cv2.createCLAHE(clipLimit=clip, tileGridSize=(tile, tile))
    img_clahe = np.zeros_like(img_uint8)
    for i in range(img_uint8.shape[2]):
        img_clahe[:, :, i] = clahe.apply(img_uint8[:, :, i])

    img_gamma = np.power(img_clahe / 255.0, gamma)
    img_gamma = (img_gamma * 255).astype(np.uint8)

    h, w = img_gamma.shape[:2]
    enhanced = cv2.resize(img_gamma, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_CUBIC)
    if enhanced.ndim == 3 and enhanced.shape[2] == 1:
        enhanced = enhanced[:, :, 0]
    cv2.imwrite(output_path, enhanced)
    return enhanced


def process_all_images(pattern="enhanced_frame_*.png", output_dir="enhanced_output", **kw):
    files = sorted(glob.glob(pattern))
    os.makedirs(output_dir, exist_ok=True)
    for idx, f in enumerate(files, 1):
        name = os.path.basename(f)
        print(f"Processing image {idx}/{len(files)}: {name}")
        enhance_image(f, os.path.join(output_dir, f"enhanced_{name}"), **kw)
    print(f'\nAll images have been enhanced and saved to the "{output_dir}" directory.')
    return len(files)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--input", default="enhanced_frame_*.png")
    ap.add_argument("--output", default="enhanced_output")
    ap.add_argument("--blur", type=int, default=3)
    ap.add_argument("--clip", type=float, default=2.0)
    ap.add_argument("--tile", type=int, default=8)
    ap.add_argument("--gamma", type=float, default=0.9)
    ap.add_argument("--scale", type=float, default=1.5)
    a = ap.parse_args()
    if process_all_images(a.input, a.output, blur=a.blur, clip=a.clip, tile=a.tile,
                          gamma=a.gamma, scale=a.scale) == 0:
        print("No files matched", a.input)
