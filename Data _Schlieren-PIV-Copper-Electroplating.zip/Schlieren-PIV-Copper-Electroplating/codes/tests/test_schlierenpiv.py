"""Fast unit tests:  python -m pytest -q codes/tests"""
import sys, pathlib, tempfile
HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import numpy as np
import cv2
from schlierenpiv import constants as K, transport as T, fields as F, schlieren as S, piv as P
from schlierenpiv import boundary_layer as B, preprocessing as PP


def test_faraday_and_film_numbers_match_manuscript():
    assert abs(T.j_faraday() - 6.09e-5) / 6.09e-5 < 2e-3
    assert abs(T.km_required(82.0) - 7.43e-7) / 7.43e-7 < 2e-3
    for s in K.STAGES:
        assert abs(T.km_film(K.DELTA_C[s]) - K.KM_OPT_QUOTED[s]) / K.KM_OPT_QUOTED[s] < 2e-3


def test_flow_and_tracer_numbers():
    assert abs(T.reynolds(0.8e-3) - 36) < 1e-9 and abs(T.reynolds(6.6e-3) - 297) < 1e-9
    assert abs(T.displacement_px(0.8e-3) - 0.64) < 1e-9
    assert T.terminal_velocity() < 0                      # tracers rise (rho_p < rho_f)
    assert abs(T.sherwood_vertical_plate(K.GR_QUOTED, K.SC) - 187.8) < 0.1


def test_profile_shapes_reach_99_percent():
    for sh in ("erf", "exp"):
        assert abs(F.shape_function(sh, 1.0) - 0.99) < 1e-3
    assert F.shape_function("film", 1.0) == 1.0


def test_concentration_field_respects_stage_values():
    f = F.make_concentration("late", "film", with_bulk_structure=False)
    assert f["C_proj_px"].shape == (360, 160)
    assert 15 < f["C_proj"][:, -1].mean() < 30 and 150 < f["C_proj"][:, 0].mean() < 162


def test_spline_inversion_accurate_inside_range_and_flags_outside():
    opt = S.Optics(read_noise=0.0)
    rng = np.random.default_rng(0)
    gain = np.ones((4, 4))
    pos, Ical = S.simulate_calibration(gain, opt, rng)
    a_true = np.full((4, 4), 0.5e-3)
    I = S.transmission(a_true, 0.0, gain, opt)
    a, ok = S.invert_spline(I, pos, Ical)
    assert ok.all() and np.abs(a - a_true).max() < 10e-6
    I_out = S.transmission(np.full((4, 4), 1.5e-3), 0.0, gain, opt)
    _, ok2 = S.invert_spline(I_out, pos, Ical)
    assert not ok2.any()


def test_integration_of_constant_gradient_is_linear():
    G = np.full((3, 21), 2.0e3)
    C = S.integrate_rows(G, np.ones_like(G, bool), 1.25e-4, 10, 100.0)
    assert abs(C[0, 20] - (100 + 2.0e3 * 10 * 1.25e-4)) < 1e-9
    assert abs(C[0, 0] - (100 - 2.0e3 * 10 * 1.25e-4)) < 1e-9


def test_integration_stops_at_invalid_pixels():
    G = np.zeros((1, 11)); v = np.ones((1, 11), bool); v[0, 8] = False
    C = S.integrate_rows(G, v, 1.0, 5, 100.0)
    assert np.isnan(C[0, 8]) and np.isnan(C[0, 10]) and not np.isnan(C[0, 7])


def test_delta99_and_flux_bound():
    d = np.linspace(0, 3e-3, 301)
    C = 18 + 82 * np.clip(d / 0.96e-3, 0, 1)
    assert abs(B.delta99(d, C, "cathode") - 0.95e-3) < 2e-5
    assert abs(B.minimum_delta99_for_flux() * 1e3 - 0.951) < 0.002


def test_piv_recovers_uniform_shift():
    rng = np.random.default_rng(1)
    a, b, _ = P.make_image_pair((200, 120), None, rng=rng, uniform_shift=(2.3, -1.1))
    r = P.multipass_piv(a, b)
    assert abs(r["dx_px"].mean() - 2.3) < 0.1 and abs(r["dy_px"].mean() + 1.1) < 0.1


def test_velocity_field_peak_and_direction():
    for st, peak in (("early", 4.1), ("developed", 6.6), ("late", 8.0)):
        vel = F.velocity_field(st)
        xx, yy = np.meshgrid(np.linspace(0, 20, 161), np.linspace(0, 45, 361))
        u, v = vel(xx, yy)
        assert abs(np.hypot(u, v).max() * 1e3 - peak) < 0.05
    u, v = F.velocity_field("developed")(np.array([1.0, 19.0]), np.array([22.0, 22.0]))
    assert v[0] < 0 < v[1]            # down at the anode, up at the cathode


def test_enhancement_script_matches_single_channel_function():
    import importlib.util
    spec = importlib.util.spec_from_file_location("image_enhancement", HERE.parent / "image_enhancement.py")
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    img = (np.random.default_rng(0).random((64, 80)) * 255).astype(np.uint8)
    with tempfile.TemporaryDirectory() as d:
        cv2.imwrite(d + "/a.png", img)
        out = m.enhance_image(d + "/a.png", d + "/b.png", scale=1.0)
    ref = PP.display_enhance_gray(img).astype(np.uint8)
    assert np.array_equal(out, ref)
