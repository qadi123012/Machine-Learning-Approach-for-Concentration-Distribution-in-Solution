"""How pre-processing choices change the reconstructed concentration (late stage, simulated).

A  raw frames, raw calibration                      (reference)
B  median 3x3 on measurement AND calibration frames (quantitative path, Section 2.4)
C  display enhancement (blur + CLAHE + gamma 0.9) on the measurement only
D  the same enhancement applied independently to every calibration frame and to the measurement
E  Gaussian blur 3x3 only, on all frames             (linear, loses resolution)

Output: concentration/simulations/S6_preprocessing_effect.png, preprocessing_effect.json
"""
import sys, pathlib, json
HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import numpy as np
import cv2
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from schlierenpiv import constants as K, fields as F, schlieren as S, preprocessing as PP

out = HERE.parent / "concentration" / "simulations"
opt = S.Optics()
fld = F.make_concentration("late", "erf")
Ct = fld["C_proj_px"]
blur_only = lambda im: cv2.GaussianBlur(im.astype(np.float32), (3, 3), 0).astype(np.float64)
scen = {
    "A raw": dict(),
    "B median 3x3 (all frames)": dict(preprocess=PP.quantitative_preprocess, cal_preprocess=PP.quantitative_preprocess),
    "C enhancement, measurement only": dict(preprocess=PP.display_enhance_gray),
    "D enhancement, every frame": dict(preprocess=PP.display_enhance_gray, cal_preprocess=PP.display_enhance_gray),
    "E Gaussian blur 3x3 (all frames)": dict(preprocess=blur_only, cal_preprocess=blur_only),
}
res, rec = {}, {}
for name, kw in scen.items():
    r = S.run_chain(fld, opt, np.random.default_rng(11), method="spline", **kw)
    Ch = r["C_hat"]; ok = ~np.isnan(Ch)
    e = (Ch - Ct)[ok]
    rowdm = (Ch - Ct) - np.nanmean(Ch - Ct, axis=1, keepdims=True)
    res[name] = dict(valid_fraction=float(r["valid"].mean()), reconstructed_fraction=float(ok.mean()),
                     rmse_kg_m3=float(np.sqrt(np.mean(e ** 2))), rmse_row_offset_removed_kg_m3=float(np.sqrt(np.nanmean(rowdm[ok] ** 2))),
                     fraction_within_2_kg_m3=float(np.mean(np.abs(e) <= 2.0)))
    rec[name] = Ch
    print(f"{name:34s} valid {res[name]['valid_fraction']:.3f}  RMSE {res[name]['rmse_kg_m3']:7.2f}  "
          f"RMSE(row offset removed) {res[name]['rmse_row_offset_removed_kg_m3']:7.2f}  within 2: {100*res[name]['fraction_within_2_kg_m3']:.0f} %")
json.dump(res, open(out / "preprocessing_effect.json", "w"), indent=2)

fig, ax = plt.subplots(1, 2, figsize=(14, 4.8))
names = list(scen)
ax[0].bar(range(len(names)), [res[n]["rmse_row_offset_removed_kg_m3"] for n in names], color=["0.5", "C0", "C3", "C3", "C2"])
ax[0].set_xticks(range(len(names))); ax[0].set_xticklabels([n.split(" ")[0] for n in names]); ax[0].set_yscale("log")
ax[0].axhline(1.0, color="k", ls=":", label="1 kg/m3 (1 sigma of the quoted 2.0 at 2 sigma)")
ax[0].set_ylabel("RMSE after removing row offset (kg/m3)"); ax[0].legend(fontsize=8); ax[0].grid(alpha=.3, axis="y")
ax[0].set_title("(a) error vs pre-processing")
x = fld["x_px"] * 1e3
ax[1].plot(x, Ct[180], "k", lw=2, label="truth")
for n, c in zip(names, ["0.5", "C0", "C3", "C1", "C2"]):
    if n[0] in "ACD":
        ax[1].plot(x, rec[n][180], ".-", ms=3, color=c, label=n)
ax[1].set_xlabel("x (mm)"); ax[1].set_ylabel("Cu2+ (kg/m3)"); ax[1].set_title("(b) profile at mid-height"); ax[1].legend(fontsize=8); ax[1].grid(alpha=.3)
fig.suptitle("Pre-processing and the knife-edge calibration (SIMULATION, late stage)")
fig.tight_layout(); fig.savefig(out / "S6_preprocessing_effect.png", dpi=150); plt.close(fig)
