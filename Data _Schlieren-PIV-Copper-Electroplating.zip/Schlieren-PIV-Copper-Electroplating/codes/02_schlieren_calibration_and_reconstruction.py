"""Simulate pixel-wise knife-edge calibration and concentration reconstruction for the 3 stages.

For each stage a stand-in concentration field (built from Tables 1 and 2) is pushed through the
Schlieren forward model, then recovered with the manuscript's procedure (pixel-wise calibration,
monotone-spline inversion, integration from the bulk). Because the truth is known, errors are exact.

Outputs (concentration/simulations/): S1_knife_edge_calibration.png, S2_forward_schlieren_stages.png,
S3_concentration_reconstruction.png, reconstruction_metrics.json
"""
import sys, pathlib, json, argparse
HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from schlierenpiv import constants as K, fields as F, schlieren as S

ap = argparse.ArgumentParser()
ap.add_argument("--out", default=str(HERE.parent / "concentration" / "simulations"))
ap.add_argument("--shape", default="erf", choices=["film", "erf", "exp"])
ap.add_argument("--seed", type=int, default=3)
args = ap.parse_args()
out = pathlib.Path(args.out); out.mkdir(parents=True, exist_ok=True)

opt = S.Optics()
rng = np.random.default_rng(args.seed)
extent = [0, K.GAP * 1e3, 0, 360 * K.PIXEL * 1e3]
results, metrics = {}, {}
for stage in K.STAGES:
    fld = F.make_concentration(stage, args.shape)
    r = S.run_chain(fld, opt, np.random.default_rng(args.seed + 1), method="spline")
    r_lin = S.run_chain(fld, opt, np.random.default_rng(args.seed + 1), method="linear")
    results[stage] = (fld, r, r_lin)
    Ct, Ch = fld["C_proj_px"], r["C_hat"]
    ok = ~np.isnan(Ch)
    err = (Ch - Ct)[ok]
    rowdm = (Ch - Ct) - np.nanmean(Ch - Ct, axis=1, keepdims=True)
    ok_l = ~np.isnan(r_lin["C_hat"])
    metrics[stage] = dict(
        valid_pixel_fraction=float(r["valid"].mean()),
        reconstructed_pixel_fraction=float(ok.mean()),
        ray_displacement_rmse_um=float(np.sqrt(np.mean((r["a_hat"] - r["a_true"])[r["valid"]] ** 2)) * 1e6),
        concentration_rmse_kg_m3=float(np.sqrt(np.mean(err ** 2))),
        concentration_bias_kg_m3=float(err.mean()),
        rmse_after_removing_row_offset_kg_m3=float(np.sqrt(np.nanmean(rowdm[ok] ** 2))),
        fraction_within_2_kg_m3=float(np.mean(np.abs(err) <= 2.0)),
        linear_slope_inversion_rmse_kg_m3=float(np.sqrt(np.mean((r_lin["C_hat"] - Ct)[ok_l] ** 2))),
        linear_slope_inversion_reconstructed_fraction=float(ok_l.mean()),
        profile_shape=args.shape,
    )
    print(stage, json.dumps({k: (round(v, 3) if isinstance(v, float) else v) for k, v in metrics[stage].items()}))
json.dump(metrics, open(out / "reconstruction_metrics.json", "w"), indent=2)

# ------------------------------------------------------------------ S1: calibration curves
fld, r, r_lin = results["late"]
pos = r["positions"] * 1e3
a_axis = np.linspace(-1.3e-3, 1.3e-3, 261)
iy, ix = 180, 80
fig, ax = plt.subplots(1, 3, figsize=(15, 4.6))
picks = {"bulk (x = 10 mm)": (180, 80), "plume (x = 2.5 mm)": (60, 20), "near cathode (x = 19 mm)": (180, 152)}
for lab, (py, px) in picks.items():
    ax[0].plot(pos, r["I_cal"][:, py, px], "o-", ms=4, label=lab)
ax[0].set_xlabel("Knife-edge displacement dx (mm)"); ax[0].set_ylabel("Gray value (counts)")
ax[0].set_title("(a) Pixel-wise calibration curves\n(10 positions, 0.19 mm step)"); ax[0].legend(fontsize=8); ax[0].grid(alpha=.3)

ax[1].imshow(r["valid"], origin="lower", extent=extent, aspect="auto", cmap="gray")
ax[1].set_xlabel("x (mm), anode at 0, cathode at 20"); ax[1].set_ylabel("y (mm)")
ax[1].set_title(f"(b) Valid (monotone, in range) pixels\nlate stage: {100*r['valid'].mean():.1f} %  (paper: 91 %)")

# inversion of a known intensity ramp through the calibration of one pixel
I_ramp = S.transmission(a_axis, 0.0, r["gain"][iy, ix], opt)
Icol = I_ramp.reshape(-1, 1)
Ical = np.repeat(r["I_cal"][:, iy, ix][:, None, None], Icol.shape[0], axis=1)
a_sp, v_sp = S.invert_spline(Icol, r["positions"], Ical)
a_ln, _ = S.invert_linear(Icol, r["positions"], Ical)
ax[2].plot(a_axis * 1e3, (a_sp[:, 0] - a_axis) * 1e6, label="monotone spline")
ax[2].plot(a_axis * 1e3, (a_ln[:, 0] - a_axis) * 1e6, label="linear slope S_ij (Eq. 10)")
bad = ~v_sp[:, 0]
ax[2].fill_between(a_axis * 1e3, -250, 250, where=bad, color="r", alpha=.12, label="outside calibrated range")
ax[2].set_ylim(-250, 250)
ax[2].set_xlabel("True ray displacement a (mm)"); ax[2].set_ylabel("Inversion error (um)")
ax[2].set_title("(c) Inversion error vs displacement"); ax[2].legend(fontsize=8); ax[2].grid(alpha=.3)
fig.tight_layout(); fig.savefig(out / "S1_knife_edge_calibration.png", dpi=150); plt.close(fig)

# ------------------------------------------------------------------ S2: forward images
fig, ax = plt.subplots(2, 3, figsize=(13, 9))
for k, stage in enumerate(K.STAGES):
    fld, r, _ = results[stage]
    h1 = ax[0, k].imshow(fld["C_proj_px"], origin="lower", extent=extent, aspect="auto", cmap="RdYlBu_r", vmin=0, vmax=165)
    ax[0, k].set_title(f"{K.STAGE_LABELS[stage]}\ntrue projected Cu2+ (kg/m3)")
    ax[1, k].imshow(r["I_meas"], origin="lower", extent=extent, aspect="auto", cmap="gray", vmin=0, vmax=255)
    ax[1, k].set_title("simulated Schlieren frame (8-bit)")
    for a in (ax[0, k], ax[1, k]):
        a.set_xlabel("x (mm), anode at 0"); a.set_ylabel("y (mm)")
fig.colorbar(h1, ax=ax[0, :].tolist(), shrink=0.8, label="kg/m3")
fig.suptitle(f"Forward model on stand-in fields (profile shape: {args.shape}). SIMULATION, not measurement")
fig.savefig(out / "S2_forward_schlieren_stages.png", dpi=150); plt.close(fig)

# ------------------------------------------------------------------ S3: reconstruction
fig, ax = plt.subplots(3, 3, figsize=(13, 13))
for k, stage in enumerate(K.STAGES):
    fld, r, _ = results[stage]
    Ct, Ch = fld["C_proj_px"], r["C_hat"]
    h = ax[0, k].imshow(Ch, origin="lower", extent=extent, aspect="auto", cmap="RdYlBu_r", vmin=0, vmax=165)
    ax[0, k].set_title(f"{K.STAGE_LABELS[stage]}\nreconstructed", fontsize=10)
    d = Ch - Ct
    he = ax[1, k].imshow(d, origin="lower", extent=extent, aspect="auto", cmap="seismic", vmin=-10, vmax=10)
    ax[1, k].set_title(f"error, RMSE {metrics[stage]['concentration_rmse_kg_m3']:.2f} kg/m3")
    yrow = 180
    ax[2, k].plot(fld["x_px"] * 1e3, Ct[yrow], "k", label="truth (depth-averaged)")
    ax[2, k].plot(fld["x_px"] * 1e3, Ch[yrow], "r.-", ms=3, label="reconstructed")
    ax[2, k].axhline(K.CB, color="0.6", ls=":")
    ax[2, k].set_xlabel("x (mm)"); ax[2, k].set_ylabel("Cu2+ (kg/m3)"); ax[2, k].set_title("profile at mid-height"); ax[2, k].legend(fontsize=8)
    ax[2, k].grid(alpha=.3)
    for a in ax[:2, k]:
        a.set_xlabel("x (mm)"); a.set_ylabel("y (mm)")
fig.colorbar(h, ax=ax[0, :].tolist(), shrink=0.7, label="kg/m3")
fig.colorbar(he, ax=ax[1, :].tolist(), shrink=0.7, label="error (kg/m3)")
fig.suptitle("Concentration recovered from simulated Schlieren frames (SIMULATION)\nwhite strips at the electrodes = saturated wall band; error pattern = bulk-reference offset from stratification", fontsize=11)
fig.savefig(out / "S3_concentration_reconstruction.png", dpi=150); plt.close(fig)
print("saved to", out)
